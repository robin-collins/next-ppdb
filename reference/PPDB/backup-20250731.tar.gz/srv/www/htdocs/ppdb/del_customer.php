<?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?><?php
  // *** Delete Record: declare variables
  if (isset($MM_delete) && (isset($MM_recordId))) {
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "customer";
    $MM_editColumn = "customerID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "home.php";
  
    if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
      $MM_editRedirectUrl = $MM_editRedirectUrl . ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
?><?php
  // *** Delete Record: construct a sql delete statement and execute it
  if (isset($MM_delete) && (isset($MM_recordId))) {
    $MM_editQuery = "delete from " . $MM_editTable . " where " . $MM_editColumn . " = " . $MM_recordId;
    if ($MM_abortEdit!=1) {
      $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
      if ($MM_editRedirectUrl) {
        header ("Location: $MM_editRedirectUrl");
      }		 
    }
  }
?><?php
$del_cust__MMColParam = "-1";
if (isset($customerID))
  {$del_cust__MMColParam = $customerID;}
?><?php
   $del_cust=$ppdb->Execute("SELECT * FROM customer WHERE customerID = " . ($del_cust__MMColParam) . "") or DIE($ppdb->ErrorMsg());
   $del_cust_numRows=0;
   $del_cust__totalRows=$del_cust->RecordCount();
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<p>ARE YOU SURE YOU WISH TO DELETE THIS CUSTOMER ?</p>
<table width="400" border="0" cellspacing="0" cellpadding="5">
  <tr> 
    <td align="right" valign="baseline" width="139"><font color="#FFFFFF" size="3">Name 
      : </font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("firstname")?>
      <?php echo $del_cust->Fields("surname")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font color="#FFFFFF" size="3">Address 
      : </font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("address")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font size="3" color="#FFFFFF"></font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("suburb")?>
      , 
      <?php echo $del_cust->Fields("postcode")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font color="#FFFFFF" size="3">Phone 
      : </font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("phone1")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font size="3" color="#FFFFFF"></font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("phone2")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font size="3" color="#FFFFFF"></font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("phone3")?>
      </font></td>
  </tr>
  <tr> 
    <td align="right" valign="baseline" width="139"><font size="3" color="#FFFFFF">Email 
      : </font></td>
    <td width="241"> <font size="3" color="#FFFFFF"> 
      <?php echo $del_cust->Fields("email")?>
      </font></td>
  </tr>
  <tr> 
    <td colspan="2" align="center"> 
      <form name="delete" method="POST" action="<?php echo $MM_editAction?>">
        <input class="button" type="submit" name="Submit" value="Yes, Delete it.">
        <input class="button" type="button" name="keep" value="No, Keep It." onclick="history.back()">
        <input type="hidden" name="MM_delete" value="true">
        <input type="hidden" name="MM_recordId" value="<?php echo $del_cust->Fields("customerID") ?>">
      </form>
    </td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
<?php
  $del_cust->Close();
?>
