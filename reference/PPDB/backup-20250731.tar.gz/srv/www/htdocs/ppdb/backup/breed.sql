-- MySQL dump 10.10
--
-- Host: localhost    Database: ppdb
-- ------------------------------------------------------
-- Server version	5.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breed`
--

DROP TABLE IF EXISTS `breed`;
CREATE TABLE `breed` (
  `breedID` mediumint(4) NOT NULL auto_increment,
  `breedname` varchar(30) NOT NULL default '',
  `avgtime` time default '00:00:00',
  `avgcost` smallint(5) default '0',
  PRIMARY KEY  (`breedID`),
  UNIQUE KEY `breedID` (`breedID`),
  UNIQUE KEY `breedname` (`breedname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=1;

--
-- Dumping data for table `breed`
--


/*!40000 ALTER TABLE `breed` DISABLE KEYS */;
LOCK TABLES `breed` WRITE;
set autocommit=0;
INSERT INTO `breed` (`breedID`, `breedname`, `avgtime`, `avgcost`) VALUES (34,'Wolfhound','01:00:00',90),(3,'Corgi','01:00:00',60),(43,'Afghan Hound','01:00:00',135),(9,'Poodle','01:00:00',70),(10,'Silky Terrier','01:00:00',60),(12,'Maltese','00:00:00',65),(13,'Pomeranian','01:00:00',65),(85,'Briard','01:00:00',115),(15,'Westie','01:00:00',70),(36,'German Shepherd','01:00:00',85),(17,'Cocker Spaniel','02:00:00',80),(37,'Airedale','01:00:00',115),(19,'Irish Setter','01:00:00',115),(20,'Schnauzer','01:00:00',80),(22,'Golden Retriever','01:00:00',85),(23,'Rough Coated Collie','01:00:00',115),(24,'New Foundland','01:00:00',120),(25,'Old English Sheepdog','02:00:00',120),(26,'King Charles Spaniel','01:00:00',65),(30,'Rottweiler','01:00:00',80),(31,'Gordon Setter','01:00:00',115),(35,'Kelpie','00:45:00',65),(38,'Belgian Shepherd','01:00:00',110),(39,'Papillion','01:00:00',65),(40,'Bassett Hound','01:00:00',65),(41,'Beagle','01:00:00',65),(42,'Bearded Collie','01:00:00',115),(44,'Bernese Mountain Dog','01:00:00',115),(45,'Bichon Frise','01:00:00',70),(46,'Border Collie','01:00:00',85),(47,'Bouvier','01:00:00',115),(48,'Boxer','01:00:00',70),(49,'Bull Terrier','01:00:00',60),(50,'CairnTerrier','01:00:00',70),(51,'Cattle Dog','01:00:00',65),(52,'Chihuahua Smooth Coat','01:00:00',45),(53,'Chihuahua Long Coat','01:00:00',60),(54,'Chow Chow','01:00:00',115),(55,'Dachshund','01:00:00',50),(56,'Dalmation','01:00:00',75),(57,'Deerhound','01:00:00',75),(58,'Dobermann','01:00:00',75),(59,'Elkhound','01:00:00',115),(60,'Fox Terrier','01:00:00',50),(61,'Great Dane','01:00:00',80),(62,'Huskie','01:00:00',85),(63,'Keeshound','01:00:00',115),(64,'Labrador','01:00:00',75),(65,'Lhasa Apso','01:00:00',65),(66,'Malamute','01:00:00',115),(67,'Pekinese','01:00:00',65),(68,'Pointer','01:00:00',70),(69,'Poodle Standard','01:00:00',115),(70,'Pyrenean Mountain Dog','01:00:00',125),(71,'Saluki','01:00:00',75),(72,'Samoyed','01:00:00',115),(73,'Shetland Sheepdog','01:00:00',70),(74,'Shih Tzu','01:00:00',65),(75,'St Bernard','01:00:00',135),(76,'Terriers Small','01:00:00',60),(77,'Terriers Large','01:00:00',80),(78,'Weimaraner','01:00:00',75),(79,'Schnauzer Minature','01:00:00',70),(80,'Schnauzer Giant','01:00:00',100),(81,'Cat','01:00:00',115),(82,'Springer Spaniel','01:00:00',110),(83,'Cavalier King Charles','01:00:00',65),(84,'Lakeland Terrier','01:00:00',75),(86,'English Setter','01:00:00',115),(89,'Aust Terrier','00:00:01',65),(90,'Yorkshire Terrier','00:00:01',60),(91,'Chinese Crested','00:00:01',65),(92,'Curly Coated Retreiver','00:00:01',115),(93,'Labradoodle','00:00:00',115),(94,'Akita','00:00:00',115),(95,'Puli','00:00:00',85),(96,'Collie X','01:00:00',115),(128,'Spoodle','00:00:00',90),(98,'Maremma','00:00:01',115),(99,'Koolie','00:00:01',75),(100,'Lowchen','01:00:00',65),(101,'Schipperke','00:00:00',65),(102,'Rabbit','00:00:01',95),(103,'Jack Russell','00:00:00',50),(104,'Whippet','00:00:00',60),(105,'Skye Terrier','00:00:01',80),(107,'Ridgeback','00:00:00',80),(109,'Mastiff','00:00:00',75),(110,'Vizula','00:00:01',70),(111,'Japanese Spitz','00:00:00',80),(112,'Staffy','00:00:01',60),(113,'Soft Coated Wheaton Terrier','00:00:01',110),(114,'Cavalier Spanial','00:00:00',70),(115,'American Cocker Spanial','00:00:00',80),(116,'Irish Terrier','00:00:00',75),(117,'Lurchin','00:00:00',65),(118,'Tibetan Spaniel','00:00:00',70),(119,'Border Terrier','00:00:00',50),(120,'Scotty','00:00:00',70),(122,'Kerry Blue Terrier','00:00:01',85),(123,'Griffon','00:00:00',65),(124,'Bull Dog','00:00:00',60),(125,'Grey Hound','00:00:00',80),(127,'Bedlington Terrier','00:00:00',75),(134,'Pug','00:00:00',50),(130,'Shiba Inu','00:00:00',60),(131,'Aust Shepherd','00:00:01',85),(132,'Groodle','00:00:00',115),(133,'Shar Pei','00:00:00',65),(135,'German Shorthaired Pointer','00:00:45',75),(137,'Japanese Chin','00:00:00',65),(138,'Welsh Springer Spanial','00:00:00',90),(139,'Schnoodle','00:00:01',70),(141,'Chinese Crested Powder Puff','00:00:00',65),(142,'Boston Terrier','00:00:00',55),(143,'German Shepherd Long Coat','00:00:00',95),(144,'Cavoodle','00:00:00',70),(145,'Flat Coated Retreiver','00:00:00',85),(146,'Golden Retreiver Long Coat','00:00:00',90),(148,'Curly Coated Retreiver small','00:00:00',90),(149,'Sealyham Terrier','00:00:00',70),(150,'Havanese','00:00:00',75),(151,'Lagotto Romagnolo','00:00:00',90),(152,'Hunterway','00:00:00',75),(153,'Musterlander','00:00:00',80),(154,'Fox Terrier Wire Hair','00:00:00',70),(155,'Smooth Coated Collie','00:00:00',70),(156,'Guinea Pig','00:00:00',70),(157,'Finnish Lapphund','00:00:00',80),(158,'Jack Russell Long Coat','00:00:00',60),(159,'Labradoodle Small','00:00:00',90),(160,'Portuguese Water Dog','00:00:00',105),(161,'Tenterfield Terrier','00:00:00',50),(162,'Moodle','01:00:00',70),(163,'Fox Hound','00:00:00',60),(164,'French Bulldog','00:00:30',60),(169,'Swedish Valhund','00:00:00',65),(166,'Nova Scotia Duck-Tolling Retri','00:00:00',100),(167,'Italian Spinone','00:00:01',90),(168,'White Swiss Shepherd','00:00:00',85),(170,'Brittany Spanial','00:00:00',80),(171,'Basset Fauve De Bretagne','00:00:00',65),(172,'Petit Basset Griffon Vendeen','00:00:00',65),(173,'Tibetan Terrier','00:00:00',70),(174,'Borzoi','00:00:00',90),(175,'Cocker Spanial small','00:00:01',70),(176,'German Spitz','00:00:00',70),(177,'Pinscher','00:00:00',60),(178,'American Staffy','00:00:00',70),(179,'Italian Greyhound','00:00:00',55),(180,'Welsh Terrier','00:00:00',80);
UNLOCK TABLES;
/*!40000 ALTER TABLE `breed` ENABLE KEYS */;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- MySQL dump 10.10
--
-- Host: localhost    Database: ppdb
-- ------------------------------------------------------
-- Server version	5.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breed`
--

DROP TABLE IF EXISTS `breed`;
CREATE TABLE `breed` (
  `breedID` mediumint(4) NOT NULL auto_increment,
  `breedname` varchar(30) NOT NULL default '',
  `avgtime` time default '00:00:00',
  `avgcost` smallint(5) default '0',
  PRIMARY KEY  (`breedID`),
  UNIQUE KEY `breedID` (`breedID`),
  UNIQUE KEY `breedname` (`breedname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=1;

--
-- Dumping data for table `breed`
--


/*!40000 ALTER TABLE `breed` DISABLE KEYS */;
LOCK TABLES `breed` WRITE;
set autocommit=0;
INSERT INTO `breed` (`breedID`, `breedname`, `avgtime`, `avgcost`) VALUES (34,'Wolfhound','01:00:00',90),(3,'Corgi','01:00:00',60),(43,'Afghan Hound','01:00:00',135),(9,'Poodle','01:00:00',70),(10,'Silky Terrier','01:00:00',60),(12,'Maltese','00:00:00',65),(13,'Pomeranian','01:00:00',65),(85,'Briard','01:00:00',115),(15,'Westie','01:00:00',70),(36,'German Shepherd','01:00:00',85),(17,'Cocker Spaniel','02:00:00',80),(37,'Airedale','01:00:00',115),(19,'Irish Setter','01:00:00',115),(20,'Schnauzer','01:00:00',80),(22,'Golden Retriever','01:00:00',85),(23,'Rough Coated Collie','01:00:00',115),(24,'New Foundland','01:00:00',120),(25,'Old English Sheepdog','02:00:00',120),(26,'King Charles Spaniel','01:00:00',65),(30,'Rottweiler','01:00:00',80),(31,'Gordon Setter','01:00:00',115),(35,'Kelpie','00:45:00',65),(38,'Belgian Shepherd','01:00:00',110),(39,'Papillion','01:00:00',65),(40,'Bassett Hound','01:00:00',65),(41,'Beagle','01:00:00',65),(42,'Bearded Collie','01:00:00',115),(44,'Bernese Mountain Dog','01:00:00',115),(45,'Bichon Frise','01:00:00',70),(46,'Border Collie','01:00:00',85),(47,'Bouvier','01:00:00',115),(48,'Boxer','01:00:00',70),(49,'Bull Terrier','01:00:00',60),(50,'CairnTerrier','01:00:00',70),(51,'Cattle Dog','01:00:00',65),(52,'Chihuahua Smooth Coat','01:00:00',45),(53,'Chihuahua Long Coat','01:00:00',60),(54,'Chow Chow','01:00:00',115),(55,'Dachshund','01:00:00',50),(56,'Dalmation','01:00:00',75),(57,'Deerhound','01:00:00',75),(58,'Dobermann','01:00:00',75),(59,'Elkhound','01:00:00',115),(60,'Fox Terrier','01:00:00',50),(61,'Great Dane','01:00:00',80),(62,'Huskie','01:00:00',85),(63,'Keeshound','01:00:00',115),(64,'Labrador','01:00:00',75),(65,'Lhasa Apso','01:00:00',65),(66,'Malamute','01:00:00',115),(67,'Pekinese','01:00:00',65),(68,'Pointer','01:00:00',70),(69,'Poodle Standard','01:00:00',115),(70,'Pyrenean Mountain Dog','01:00:00',125),(71,'Saluki','01:00:00',75),(72,'Samoyed','01:00:00',115),(73,'Shetland Sheepdog','01:00:00',70),(74,'Shih Tzu','01:00:00',65),(75,'St Bernard','01:00:00',135),(76,'Terriers Small','01:00:00',60),(77,'Terriers Large','01:00:00',80),(78,'Weimaraner','01:00:00',75),(79,'Schnauzer Minature','01:00:00',70),(80,'Schnauzer Giant','01:00:00',100),(81,'Cat','01:00:00',115),(82,'Springer Spaniel','01:00:00',110),(83,'Cavalier King Charles','01:00:00',65),(84,'Lakeland Terrier','01:00:00',75),(86,'English Setter','01:00:00',115),(89,'Aust Terrier','00:00:01',65),(90,'Yorkshire Terrier','00:00:01',60),(91,'Chinese Crested','00:00:01',65),(92,'Curly Coated Retreiver','00:00:01',115),(93,'Labradoodle','00:00:00',115),(94,'Akita','00:00:00',115),(95,'Puli','00:00:00',85),(96,'Collie X','01:00:00',115),(128,'Spoodle','00:00:00',90),(98,'Maremma','00:00:01',115),(99,'Koolie','00:00:01',75),(100,'Lowchen','01:00:00',65),(101,'Schipperke','00:00:00',65),(102,'Rabbit','00:00:01',95),(103,'Jack Russell','00:00:00',50),(104,'Whippet','00:00:00',60),(105,'Skye Terrier','00:00:01',80),(107,'Ridgeback','00:00:00',80),(109,'Mastiff','00:00:00',75),(110,'Vizula','00:00:01',70),(111,'Japanese Spitz','00:00:00',80),(112,'Staffy','00:00:01',60),(113,'Soft Coated Wheaton Terrier','00:00:01',110),(114,'Cavalier Spanial','00:00:00',70),(115,'American Cocker Spanial','00:00:00',80),(116,'Irish Terrier','00:00:00',75),(117,'Lurchin','00:00:00',65),(118,'Tibetan Spaniel','00:00:00',70),(119,'Border Terrier','00:00:00',50),(120,'Scotty','00:00:00',70),(122,'Kerry Blue Terrier','00:00:01',85),(123,'Griffon','00:00:00',65),(124,'Bull Dog','00:00:00',60),(125,'Grey Hound','00:00:00',80),(127,'Bedlington Terrier','00:00:00',75),(134,'Pug','00:00:00',50),(130,'Shiba Inu','00:00:00',60),(131,'Aust Shepherd','00:00:01',85),(132,'Groodle','00:00:00',115),(133,'Shar Pei','00:00:00',65),(135,'German Shorthaired Pointer','00:00:45',75),(137,'Japanese Chin','00:00:00',65),(138,'Welsh Springer Spanial','00:00:00',90),(139,'Schnoodle','00:00:01',70),(141,'Chinese Crested Powder Puff','00:00:00',65),(142,'Boston Terrier','00:00:00',55),(143,'German Shepherd Long Coat','00:00:00',95),(144,'Cavoodle','00:00:00',70),(145,'Flat Coated Retreiver','00:00:00',85),(146,'Golden Retreiver Long Coat','00:00:00',90),(148,'Curly Coated Retreiver small','00:00:00',90),(149,'Sealyham Terrier','00:00:00',70),(150,'Havanese','00:00:00',75),(151,'Lagotto Romagnolo','00:00:00',90),(152,'Hunterway','00:00:00',75),(153,'Musterlander','00:00:00',80),(154,'Fox Terrier Wire Hair','00:00:00',70),(155,'Smooth Coated Collie','00:00:00',70),(156,'Guinea Pig','00:00:00',70),(157,'Finnish Lapphund','00:00:00',80),(158,'Jack Russell Long Coat','00:00:00',60),(159,'Labradoodle Small','00:00:00',90),(160,'Portuguese Water Dog','00:00:00',105),(161,'Tenterfield Terrier','00:00:00',50),(162,'Moodle','01:00:00',70),(163,'Fox Hound','00:00:00',60),(164,'French Bulldog','00:00:30',60),(169,'Swedish Valhund','00:00:00',65),(166,'Nova Scotia Duck-Tolling Retri','00:00:00',100),(167,'Italian Spinone','00:00:01',90),(168,'White Swiss Shepherd','00:00:00',85),(170,'Brittany Spanial','00:00:00',80),(171,'Basset Fauve De Bretagne','00:00:00',65),(172,'Petit Basset Griffon Vendeen','00:00:00',65),(173,'Tibetan Terrier','00:00:00',70),(174,'Borzoi','00:00:00',90),(175,'Cocker Spanial small','00:00:01',70),(176,'German Spitz','00:00:00',70),(177,'Pinscher','00:00:00',60),(178,'American Staffy','00:00:00',70),(179,'Italian Greyhound','00:00:00',55),(180,'Welsh Terrier','00:00:00',80);
UNLOCK TABLES;
/*!40000 ALTER TABLE `breed` ENABLE KEYS */;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- MySQL dump 10.10
--
-- Host: localhost    Database: ppdb
-- ------------------------------------------------------
-- Server version	5.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breed`
--

DROP TABLE IF EXISTS `breed`;
CREATE TABLE `breed` (
  `breedID` mediumint(4) NOT NULL auto_increment,
  `breedname` varchar(30) NOT NULL default '',
  `avgtime` time default '00:00:00',
  `avgcost` smallint(5) default '0',
  PRIMARY KEY  (`breedID`),
  UNIQUE KEY `breedID` (`breedID`),
  UNIQUE KEY `breedname` (`breedname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=1;

--
-- Dumping data for table `breed`
--


/*!40000 ALTER TABLE `breed` DISABLE KEYS */;
LOCK TABLES `breed` WRITE;
set autocommit=0;
INSERT INTO `breed` (`breedID`, `breedname`, `avgtime`, `avgcost`) VALUES (34,'Wolfhound','01:00:00',90),(3,'Corgi','01:00:00',60),(43,'Afghan Hound','01:00:00',135),(9,'Poodle','01:00:00',70),(10,'Silky Terrier','01:00:00',60),(12,'Maltese','00:00:00',65),(13,'Pomeranian','01:00:00',65),(85,'Briard','01:00:00',115),(15,'Westie','01:00:00',70),(36,'German Shepherd','01:00:00',85),(17,'Cocker Spaniel','02:00:00',80),(37,'Airedale','01:00:00',115),(19,'Irish Setter','01:00:00',115),(20,'Schnauzer','01:00:00',80),(22,'Golden Retriever','01:00:00',85),(23,'Rough Coated Collie','01:00:00',115),(24,'New Foundland','01:00:00',120),(25,'Old English Sheepdog','02:00:00',120),(26,'King Charles Spaniel','01:00:00',65),(30,'Rottweiler','01:00:00',80),(31,'Gordon Setter','01:00:00',115),(35,'Kelpie','00:45:00',65),(38,'Belgian Shepherd','01:00:00',110),(39,'Papillion','01:00:00',65),(40,'Bassett Hound','01:00:00',65),(41,'Beagle','01:00:00',65),(42,'Bearded Collie','01:00:00',115),(44,'Bernese Mountain Dog','01:00:00',115),(45,'Bichon Frise','01:00:00',70),(46,'Border Collie','01:00:00',85),(47,'Bouvier','01:00:00',115),(48,'Boxer','01:00:00',70),(49,'Bull Terrier','01:00:00',60),(50,'CairnTerrier','01:00:00',70),(51,'Cattle Dog','01:00:00',65),(52,'Chihuahua Smooth Coat','01:00:00',45),(53,'Chihuahua Long Coat','01:00:00',60),(54,'Chow Chow','01:00:00',115),(55,'Dachshund','01:00:00',50),(56,'Dalmation','01:00:00',75),(57,'Deerhound','01:00:00',75),(58,'Dobermann','01:00:00',75),(59,'Elkhound','01:00:00',115),(60,'Fox Terrier','01:00:00',50),(61,'Great Dane','01:00:00',80),(62,'Huskie','01:00:00',85),(63,'Keeshound','01:00:00',115),(64,'Labrador','01:00:00',75),(65,'Lhasa Apso','01:00:00',65),(66,'Malamute','01:00:00',115),(67,'Pekinese','01:00:00',65),(68,'Pointer','01:00:00',70),(69,'Poodle Standard','01:00:00',115),(70,'Pyrenean Mountain Dog','01:00:00',125),(71,'Saluki','01:00:00',75),(72,'Samoyed','01:00:00',115),(73,'Shetland Sheepdog','01:00:00',70),(74,'Shih Tzu','01:00:00',65),(75,'St Bernard','01:00:00',135),(76,'Terriers Small','01:00:00',60),(77,'Terriers Large','01:00:00',80),(78,'Weimaraner','01:00:00',75),(79,'Schnauzer Minature','01:00:00',70),(80,'Schnauzer Giant','01:00:00',100),(81,'Cat','01:00:00',115),(82,'Springer Spaniel','01:00:00',110),(83,'Cavalier King Charles','01:00:00',65),(84,'Lakeland Terrier','01:00:00',75),(86,'English Setter','01:00:00',115),(89,'Aust Terrier','00:00:01',65),(90,'Yorkshire Terrier','00:00:01',60),(91,'Chinese Crested','00:00:01',65),(92,'Curly Coated Retreiver','00:00:01',115),(93,'Labradoodle','00:00:00',115),(94,'Akita','00:00:00',115),(95,'Puli','00:00:00',85),(96,'Collie X','01:00:00',115),(128,'Spoodle','00:00:00',90),(98,'Maremma','00:00:01',115),(99,'Koolie','00:00:01',75),(100,'Lowchen','01:00:00',65),(101,'Schipperke','00:00:00',65),(102,'Rabbit','00:00:01',95),(103,'Jack Russell','00:00:00',50),(104,'Whippet','00:00:00',60),(105,'Skye Terrier','00:00:01',80),(107,'Ridgeback','00:00:00',80),(109,'Mastiff','00:00:00',75),(110,'Vizula','00:00:01',70),(111,'Japanese Spitz','00:00:00',80),(112,'Staffy','00:00:01',60),(113,'Soft Coated Wheaton Terrier','00:00:01',110),(114,'Cavalier Spanial','00:00:00',70),(115,'American Cocker Spanial','00:00:00',80),(116,'Irish Terrier','00:00:00',75),(117,'Lurchin','00:00:00',65),(118,'Tibetan Spaniel','00:00:00',70),(119,'Border Terrier','00:00:00',50),(120,'Scotty','00:00:00',70),(122,'Kerry Blue Terrier','00:00:01',85),(123,'Griffon','00:00:00',65),(124,'Bull Dog','00:00:00',60),(125,'Grey Hound','00:00:00',80),(127,'Bedlington Terrier','00:00:00',75),(134,'Pug','00:00:00',50),(130,'Shiba Inu','00:00:00',60),(131,'Aust Shepherd','00:00:01',85),(132,'Groodle','00:00:00',115),(133,'Shar Pei','00:00:00',65),(135,'German Shorthaired Pointer','00:00:45',75),(137,'Japanese Chin','00:00:00',65),(138,'Welsh Springer Spanial','00:00:00',90),(139,'Schnoodle','00:00:01',70),(141,'Chinese Crested Powder Puff','00:00:00',65),(142,'Boston Terrier','00:00:00',55),(143,'German Shepherd Long Coat','00:00:00',95),(144,'Cavoodle','00:00:00',70),(145,'Flat Coated Retreiver','00:00:00',85),(146,'Golden Retreiver Long Coat','00:00:00',90),(148,'Curly Coated Retreiver small','00:00:00',90),(149,'Sealyham Terrier','00:00:00',70),(150,'Havanese','00:00:00',75),(151,'Lagotto Romagnolo','00:00:00',90),(152,'Hunterway','00:00:00',75),(153,'Musterlander','00:00:00',80),(154,'Fox Terrier Wire Hair','00:00:00',70),(155,'Smooth Coated Collie','00:00:00',70),(156,'Guinea Pig','00:00:00',70),(157,'Finnish Lapphund','00:00:00',80),(158,'Jack Russell Long Coat','00:00:00',60),(159,'Labradoodle Small','00:00:00',90),(160,'Portuguese Water Dog','00:00:00',105),(161,'Tenterfield Terrier','00:00:00',50),(162,'Moodle','01:00:00',70),(163,'Fox Hound','00:00:00',60),(164,'French Bulldog','00:00:30',60),(169,'Swedish Valhund','00:00:00',65),(166,'Nova Scotia Duck-Tolling Retri','00:00:00',100),(167,'Italian Spinone','00:00:01',90),(168,'White Swiss Shepherd','00:00:00',85),(170,'Brittany Spanial','00:00:00',80),(171,'Basset Fauve De Bretagne','00:00:00',65),(172,'Petit Basset Griffon Vendeen','00:00:00',65),(173,'Tibetan Terrier','00:00:00',70),(174,'Borzoi','00:00:00',90),(175,'Cocker Spanial small','00:00:01',70),(176,'German Spitz','00:00:00',70),(177,'Pinscher','00:00:00',60),(178,'American Staffy','00:00:00',70),(179,'Italian Greyhound','00:00:00',55),(180,'Welsh Terrier','00:00:00',80);
UNLOCK TABLES;
/*!40000 ALTER TABLE `breed` ENABLE KEYS */;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- MySQL dump 10.10
--
-- Host: localhost    Database: ppdb
-- ------------------------------------------------------
-- Server version	5.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breed`
--

DROP TABLE IF EXISTS `breed`;
CREATE TABLE `breed` (
  `breedID` mediumint(4) NOT NULL auto_increment,
  `breedname` varchar(30) NOT NULL default '',
  `avgtime` time default '00:00:00',
  `avgcost` smallint(5) default '0',
  PRIMARY KEY  (`breedID`),
  UNIQUE KEY `breedID` (`breedID`),
  UNIQUE KEY `breedname` (`breedname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=1;

--
-- Dumping data for table `breed`
--


/*!40000 ALTER TABLE `breed` DISABLE KEYS */;
LOCK TABLES `breed` WRITE;
set autocommit=0;
INSERT INTO `breed` (`breedID`, `breedname`, `avgtime`, `avgcost`) VALUES (34,'Wolfhound','01:00:00',90),(3,'Corgi','01:00:00',60),(43,'Afghan Hound','01:00:00',135),(9,'Poodle','01:00:00',70),(10,'Silky Terrier','01:00:00',60),(12,'Maltese','00:00:00',65),(13,'Pomeranian','01:00:00',65),(85,'Briard','01:00:00',115),(15,'Westie','01:00:00',70),(36,'German Shepherd','01:00:00',85),(17,'Cocker Spaniel','02:00:00',80),(37,'Airedale','01:00:00',115),(19,'Irish Setter','01:00:00',115),(20,'Schnauzer','01:00:00',80),(22,'Golden Retriever','01:00:00',85),(23,'Rough Coated Collie','01:00:00',115),(24,'New Foundland','01:00:00',120),(25,'Old English Sheepdog','02:00:00',120),(26,'King Charles Spaniel','01:00:00',65),(30,'Rottweiler','01:00:00',80),(31,'Gordon Setter','01:00:00',115),(35,'Kelpie','00:45:00',65),(38,'Belgian Shepherd','01:00:00',110),(39,'Papillion','01:00:00',65),(40,'Bassett Hound','01:00:00',65),(41,'Beagle','01:00:00',65),(42,'Bearded Collie','01:00:00',115),(44,'Bernese Mountain Dog','01:00:00',115),(45,'Bichon Frise','01:00:00',70),(46,'Border Collie','01:00:00',85),(47,'Bouvier','01:00:00',115),(48,'Boxer','01:00:00',70),(49,'Bull Terrier','01:00:00',60),(50,'CairnTerrier','01:00:00',70),(51,'Cattle Dog','01:00:00',65),(52,'Chihuahua Smooth Coat','01:00:00',45),(53,'Chihuahua Long Coat','01:00:00',60),(54,'Chow Chow','01:00:00',115),(55,'Dachshund','01:00:00',50),(56,'Dalmation','01:00:00',75),(57,'Deerhound','01:00:00',75),(58,'Dobermann','01:00:00',75),(59,'Elkhound','01:00:00',115),(60,'Fox Terrier','01:00:00',50),(61,'Great Dane','01:00:00',80),(62,'Huskie','01:00:00',85),(63,'Keeshound','01:00:00',115),(64,'Labrador','01:00:00',75),(65,'Lhasa Apso','01:00:00',65),(66,'Malamute','01:00:00',115),(67,'Pekinese','01:00:00',65),(68,'Pointer','01:00:00',70),(69,'Poodle Standard','01:00:00',115),(70,'Pyrenean Mountain Dog','01:00:00',125),(71,'Saluki','01:00:00',75),(72,'Samoyed','01:00:00',115),(73,'Shetland Sheepdog','01:00:00',70),(74,'Shih Tzu','01:00:00',65),(75,'St Bernard','01:00:00',135),(76,'Terriers Small','01:00:00',60),(77,'Terriers Large','01:00:00',80),(78,'Weimaraner','01:00:00',75),(79,'Schnauzer Minature','01:00:00',70),(80,'Schnauzer Giant','01:00:00',100),(81,'Cat','01:00:00',115),(82,'Springer Spaniel','01:00:00',110),(83,'Cavalier King Charles','01:00:00',65),(84,'Lakeland Terrier','01:00:00',75),(86,'English Setter','01:00:00',115),(89,'Aust Terrier','00:00:01',65),(90,'Yorkshire Terrier','00:00:01',60),(91,'Chinese Crested','00:00:01',65),(92,'Curly Coated Retreiver','00:00:01',115),(93,'Labradoodle','00:00:00',115),(94,'Akita','00:00:00',115),(95,'Puli','00:00:00',85),(96,'Collie X','01:00:00',115),(128,'Spoodle','00:00:00',90),(98,'Maremma','00:00:01',115),(99,'Koolie','00:00:01',75),(100,'Lowchen','01:00:00',65),(101,'Schipperke','00:00:00',65),(102,'Rabbit','00:00:01',95),(103,'Jack Russell','00:00:00',50),(104,'Whippet','00:00:00',60),(105,'Skye Terrier','00:00:01',80),(107,'Ridgeback','00:00:00',80),(109,'Mastiff','00:00:00',75),(110,'Vizula','00:00:01',70),(111,'Japanese Spitz','00:00:00',80),(112,'Staffy','00:00:01',60),(113,'Soft Coated Wheaton Terrier','00:00:01',110),(114,'Cavalier Spanial','00:00:00',70),(115,'American Cocker Spanial','00:00:00',80),(116,'Irish Terrier','00:00:00',75),(117,'Lurchin','00:00:00',65),(118,'Tibetan Spaniel','00:00:00',70),(119,'Border Terrier','00:00:00',50),(120,'Scotty','00:00:00',70),(122,'Kerry Blue Terrier','00:00:01',85),(123,'Griffon','00:00:00',65),(124,'Bull Dog','00:00:00',60),(125,'Grey Hound','00:00:00',80),(127,'Bedlington Terrier','00:00:00',75),(134,'Pug','00:00:00',50),(130,'Shiba Inu','00:00:00',60),(131,'Aust Shepherd','00:00:01',85),(132,'Groodle','00:00:00',115),(133,'Shar Pei','00:00:00',65),(135,'German Shorthaired Pointer','00:00:45',75),(137,'Japanese Chin','00:00:00',65),(138,'Welsh Springer Spanial','00:00:00',90),(139,'Schnoodle','00:00:01',70),(141,'Chinese Crested Powder Puff','00:00:00',65),(142,'Boston Terrier','00:00:00',55),(143,'German Shepherd Long Coat','00:00:00',95),(144,'Cavoodle','00:00:00',70),(145,'Flat Coated Retreiver','00:00:00',85),(146,'Golden Retreiver Long Coat','00:00:00',90),(148,'Curly Coated Retreiver small','00:00:00',90),(149,'Sealyham Terrier','00:00:00',70),(150,'Havanese','00:00:00',75),(151,'Lagotto Romagnolo','00:00:00',90),(152,'Hunterway','00:00:00',75),(153,'Musterlander','00:00:00',80),(154,'Fox Terrier Wire Hair','00:00:00',70),(155,'Smooth Coated Collie','00:00:00',70),(156,'Guinea Pig','00:00:00',70),(157,'Finnish Lapphund','00:00:00',80),(158,'Jack Russell Long Coat','00:00:00',60),(159,'Labradoodle Small','00:00:00',90),(160,'Portuguese Water Dog','00:00:00',105),(161,'Tenterfield Terrier','00:00:00',50),(162,'Moodle','01:00:00',70),(163,'Fox Hound','00:00:00',60),(164,'French Bulldog','00:00:30',60),(169,'Swedish Valhund','00:00:00',65),(166,'Nova Scotia Duck-Tolling Retri','00:00:00',100),(167,'Italian Spinone','00:00:01',90),(168,'White Swiss Shepherd','00:00:00',85),(170,'Brittany Spanial','00:00:00',80),(171,'Basset Fauve De Bretagne','00:00:00',65),(172,'Petit Basset Griffon Vendeen','00:00:00',65),(173,'Tibetan Terrier','00:00:00',70),(174,'Borzoi','00:00:00',90),(175,'Cocker Spanial small','00:00:01',70),(176,'German Spitz','00:00:00',70),(177,'Pinscher','00:00:00',60),(178,'American Staffy','00:00:00',70),(179,'Italian Greyhound','00:00:00',55),(180,'Welsh Terrier','00:00:00',80);
UNLOCK TABLES;
/*!40000 ALTER TABLE `breed` ENABLE KEYS */;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

