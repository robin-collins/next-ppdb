<?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?><?php
  // *** Update Record: set variables
  
  if (isset($MM_update) && (isset($MM_recordId))) {
  
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "customer";
    $MM_editColumn = "customerID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "show_customer.php";
    $MM_fieldsStr = "firstname|value|surname|value|address|value|phone1|value|suburb|value|phone2|value|postcode|value|phone3|value|email|value";
    $MM_columnsStr = "firstname|',none,''|surname|',none,''|address|',none,''|phone1|',none,''|suburb|',none,''|phone2|',none,''|postcode|none,none,NULL|phone3|',none,''|email|',none,''";
  
    // create the $MM_fields and $MM_columns arrays
   $MM_fields = Explode("|", $MM_fieldsStr);
   $MM_columns = Explode("|", $MM_columnsStr);
    
    // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
    }
  
    // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
  ?><?php
  // *** Delete Record: declare variables
  if (isset($MM_delete) && (isset($MM_recordId))) {
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "animal";
    $MM_editColumn = "animalID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "show_customer.php";
  
    if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
      $MM_editRedirectUrl = $MM_editRedirectUrl . ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
?><?php
  // *** Update Record: construct a sql update statement and execute it
  
 if (isset($MM_update) && (isset($MM_recordId))) {
  
	// create the sql update statement
	$MM_editQuery = "update " . $MM_editTable . " set ";
	for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) 
	{
		$formVal = $MM_fields[$i+1];
		$MM_typesArray = Explode(",", $MM_columns[$i+1]);
		$delim =    ($MM_typesArray[0] != "none") ? $MM_typesArray[0] : "";
		$altVal =   ($MM_typesArray[1] != "none") ? $MM_typesArray[1] : "";
		$emptyVal = ($MM_typesArray[2] != "none") ? $MM_typesArray[2] : "";
		if ($formVal == "" || !isset($formVal)) 
		{
			$formVal = $emptyVal;
		} 
		else 
		{
			if ($altVal != "") 
			{
				$formVal = $altVal;
			} 
			else if ($delim == "'") 
			{ // do not escape quotes in PHP4
				$formVal = "'" .$formVal . "'";
			} 
			else 
			{
				$formVal = $delim . $formVal . $delim;
			}
		}
		if ($i != 0)
			{
				$MM_editQuery = $MM_editQuery . ", " . $MM_columns[$i] . " = " . $formVal;
			}
			else
			{
				$MM_editQuery = $MM_editQuery . $MM_columns[$i] . " = " . $formVal;
			}
		}

	$MM_editQuery = $MM_editQuery . " where " . $MM_editColumn . " = " . $MM_recordId;

	if ($MM_abortEdit != 1)
	{
		// execute the insert
		$queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
		if ($MM_editRedirectUrl) 
		{
			header ("Location: $MM_editRedirectUrl");
		}		 
	}
}
?><?php
  // *** Delete Record: construct a sql delete statement and execute it
  if (isset($MM_delete) && (isset($MM_recordId))) {
    $MM_editQuery = "delete from " . $MM_editTable . " where " . $MM_editColumn . " = " . $MM_recordId;
    if ($MM_abortEdit!=1) {
      $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
      if ($MM_editRedirectUrl) {
        header ("Location: $MM_editRedirectUrl");
      }		 
    }
  }
?><?php
$customer__MMColParam = "1";
if (isset($_GET["customerID"]))
  {$customer__MMColParam = $_GET["customerID"];}
?><?php
$animals__MMColParam = "1";
if (isset($_GET["customerID"]))
  {$animals__MMColParam = $_GET["customerID"];}
?><?php
   $customer=$ppdb->Execute("SELECT * FROM customer WHERE customerID = " . ($customer__MMColParam) . "") or DIE($ppdb->ErrorMsg());
   $customer_numRows=0;
   $customer__totalRows=$customer->RecordCount();
?><?php
   $animals=$ppdb->Execute("SELECT animal.*,breed.breedname  FROM animal,breed  WHERE ((customerID = " . ($animals__MMColParam) . ")&&(animal.breedID=breed.breedID))  ORDER BY animalname ASC") or DIE($ppdb->ErrorMsg());
   $animals_numRows=0;
   $animals__totalRows=$animals->RecordCount();
?><?php
   $Repeat1__numRows = -1;
   $Repeat1__index= 0;
   $animals_numRows = $animals_numRows + $Repeat1__numRows;
?>





<html>
<head>
<title>
<?php echo $customer->Fields("firstname")?>
 
<?php echo $customer->Fields("surname")?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>

<body>
<table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
  <tr>
    <td>
      
        <table border=0 cellpadding=2 cellspacing=0 align="left" width="100%">
        <form method="POST" action="<?php echo $MM_editAction?>" name="form1">
          <tr valign="baseline"> 
            <td nowrap align="right" class="medium-text">First Name :</td>
            <td> 
              <input class="input_field" type="text" name="firstname" value="<?php echo $customer->Fields("firstname")?>" size="18" tabindex="1">
            </td>
            <td align="right" valign="bottom" class="medium-text">Surname :</td>
            <td> 
              <input class="input_field"  type="text" name="surname" value="<?php echo $customer->Fields("surname")?>" size="18" tabindex="2">
            </td>
          </tr>
          <tr> 
            <td nowrap align="right" valign="top" class="medium-text">Address 
              :</td>
            <td valign="baseline"> 
              <textarea class="input_fieldMultiline"  name="address" cols="25" rows="3" tabindex="3"><?php echo $customer->Fields("address")?></textarea>
            </td>
            <td valign="bottom" align="right" class="medium-text">Phone1 :</td>
            <td valign="baseline"> 
              <input class="input_field"  type="text" name="phone1" value="<?php echo $customer->Fields("phone1")?>" size="13" tabindex="6" maxlength="10">
            </td>
          </tr>
          <tr valign="baseline"> 
            <td nowrap align="right" class="medium-text">Suburb :</td>
            <td> 
              <input class="input_field"  type="text" name="suburb" value="<?php echo $customer->Fields("suburb")?>" size="18" tabindex="4">
            </td>
            <td align="right" valign="bottom" class="medium-text">Phone2 :</td>
            <td> 
              <input class="input_field"  type="text" name="phone2" value="<?php echo $customer->Fields("phone2")?>" size="13" tabindex="7" maxlength="10">
            </td>
          </tr>
          <tr valign="baseline"> 
            <td nowrap align="right" class="medium-text">Postcode :</td>
            <td> 
              <input class="input_field"  type="text" name="postcode" value="<?php echo $customer->Fields("postcode")?>" size="6" tabindex="5" maxlength="4">
            </td>
            <td align="right" valign="bottom" class="medium-text">Phone3 :</td>
            <td> 
              <input class="input_fieldMultiline"  type="text" name="phone3" value="<?php echo $customer->Fields("phone3")?>" size="13" tabindex="8" maxlength="10">
            </td>
          </tr>
          <tr valign="baseline"> 
            <td nowrap align="right" class="medium-text"> 
              <?php 
			  if ($customer->Fields('email')!="") {?>
              <a class="medium-text" href="mailto:<?php echo $customer->Fields("email");?>" target="_blank"> 
              <img src="Flash/email.gif" width="20" height="20" alt="Send Customer EMAIL!" name="email"></a> 
              <?php };?>
              Email :</td>
            <td> 
              <input type="text" name="email" size="25" maxlength="200" value="<?php echo $customer->Fields("email")?>" class="input_field">
            </td>
            <td>&nbsp;</td>
            <td> 
              <input class="button"  type="submit" value="Update Record" name="submit">
            </td>
          </tr>
          <input type="hidden" name="MM_update" value="true">
          <input type="hidden" name="MM_recordId" value="<?php echo $customer->Fields("customerID") ?>">
        </form>
        <tr valign="baseline" align="center"> 
          <td nowrap class="medium-text" colspan="4"> 
            <form name="DELETE" method="post" action="del_customer.php">
              <input type="hidden" name="customerID" value="<?php echo $customer->Fields("customerID")?>">
              <input class="button" type="submit" name="dele" value="DELETE CUSTOMER">
            </form>
          </td>
        </tr>
        </table>
        <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr valign="middle" align="center">
          <td>
            <form name="form2" method="post" action="add_animal.php?customerID=<?php echo $customer->Fields("customerID");?>">
              <input class="button" type="submit" name="Submit" value="Add Animal">
            </form>
          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <?php while (($Repeat1__numRows-- != 0) && (!$animals->EOF)) 
   { 
?>
        <tr valign="middle" align="left">
          <td> 
            <font size="2"><a class="medium-text" href="show_animal.php?animalID=<?php echo $animals->Fields("animalID")?>"> 
            <img src="Flash/questionmark.gif" width="20" height="20" alt="Show / Edit Animal Info" border="0"> 
            </a><a class="medium-text" href="show_animal.php?animalID=<?php echo $animals->Fields("animalID")?>">
            <?php echo $animals->Fields("animalname")?>
            </a> </font></td>
          <td> 
            <font size="2"><a class="large-text" href="show_animal.php?animalID=<?php echo $animals->Fields("animalID")?>"> 
            <?php echo $animals->Fields("breedname")?>
            </a> </font></td>
          <td> 
            <font size="2"><a class="large-text" href="show_animal.php?animalID=<?php echo $animals->Fields("animalID")?>"> 
            <?php echo $animals->Fields("colour")?>
            </a> </font></td>
          <td> 
            <font size="2"><a class="large-text" href="show_animal.php?animalID=<?php echo $animals->Fields("animalID")?>"> 
            <?php echo $animals->Fields("SEX")?>
            </a> </font></td>
          <td>            
            <form name="form3" method="POST" action="<?php echo $MM_editAction?>">
              <font size="2">
              <input class="button" type="submit" name="Submit2" value="Delete">
              <input type="hidden" name="animalID" value="<?php echo $animals->Fields("animalID")?>">
              <input type="hidden" name="MM_delete" value="true">
  
              <input type="hidden" name="MM_recordId2" value="<?php echo $animals->Fields("animalID") ?>">
            </font>
              <input type="hidden" name="MM_recordId" value="<?php echo $animals->Fields("animalID") ?>">
            </form>
          </td>
        </tr>
        <?php
  $Repeat1__index++;
  $animals->MoveNext();
}
?>

      </table>
    </td>
  </tr>
  <tr>
    <td align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>
</table>
</body>
</html>
<?php
  $customer->Close();
?>
<?php
  $animals->Close();
?>
