<?php require_once('Connections/ppdb1.php'); ?>
<?php
// begin Recordset
$colname__allnotes = '1';
if (isset($_GET['animalID'])) {
  $colname__allnotes = $_GET['animalID'];
}
$query_allnotes = sprintf("SELECT * FROM notes WHERE animalID = %s ORDER BY noteID DESC", $colname__allnotes);
$allnotes = $ppdb1->SelectLimit($query_allnotes) or die($ppdb1->ErrorMsg());
$totalRows_allnotes = $allnotes->RecordCount();
// end Recordset

// begin Recordset
$colname__animal = '1';
if (isset($_GET['animalID'])) {
  $colname__animal = $_GET['animalID'];
}
$query_animal = sprintf("SELECT * FROM animal WHERE animalID = %s", $colname__animal);
$animal = $ppdb1->SelectLimit($query_animal) or die($ppdb1->ErrorMsg());
$totalRows_animal = $animal->RecordCount();
// end Recordset
 //PHP ADODB document - made with PHAkt 2.0.60?>

<html>
<head>
<title>animal notes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="tpp2.css" rel="stylesheet" type="text/css">
</head>

<body>
<p>All Notes for <strong><?php echo $animal->Fields('animalname'); ?></strong></p>
<p><strong><a href="show_animal.php?animalID=<?php echo $animal->Fields('animalID'); ?>">Back to Animal Info Page</a></strong></p>
<p></p>
<?php
  while (!$allnotes->EOF) {
?>
<p><strong><font color="#FFFF00"><?php echo $allnotes->Fields('date'); ?></font></strong> <br>
  <?php echo $allnotes->Fields('notes'); ?> </p>
<?php
    $allnotes->MoveNext();
  }
?>
<p>&nbsp;</p>
</body>
</html>
<?php
$allnotes->Close();

$animal->Close();
?>

