<?php
// mysqldump -c --quote-names --user=root --password=6uldv8 ppdb >> ppdb.sql
$CurrentDir = getcwd();
chdir("backup");



$MySQLHost = "localhost";
$MySQLUser = "root";
$MySQLPass = "6uldv8";

mysql_connect($MySQLHost, $MySQLUser, $MySQLPass) or
        die("Could not connect: " . mysql_error());
$db = 'ppdb';

$tables = mysql_list_tables($db);

while (list($table_name) = mysql_fetch_array($tables)) {
exec("/usr/bin/mysqldump -c --no-autocommit --quote-names --user=root --password=6uldv8 ppdb $table_name >> $table_name.sql");
}



$tar = "tar -czf $CurrentDir/backup/backup-".date("Ymd").".tar.gz $CurrentDir/ --exclude=$CurrentDir/backup/backup-".date("Ymd").".tar.gz";

exec($tar);
/*
*/
echo "<html><head><title>Backup Data</title></head>";
echo "<body>";
echo "Backup Complete, Download beginning.";
$filesize = filesize($CurrentDir."/backup/backup-".date("Ymd").".tar.gz");
$filesize = $filesize / 8;
echo "Backup file backup-".date("Ymd").".tar.gz size = ".$filesize."<br>";
echo '<META HTTP-EQUIV="REFRESH" content="5;URL=backup/backup-'.date("Ymd").'.tar.gz">';
echo "When backup complete click below";
echo '<form action="clean-backup-folder.php" method="post" name="form1" target="_self">
  <input type="submit" name="Submit" value="Finished">
</form>';
echo "</body></html>";
//header("Location: /backup/backup-".date("Ymd").".tar");
?>