<?php
  $count=0;
  $sum=0;
  $today=date('Y-m-j');
?><?php
  

  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
$todays_dogs__MMColParam = "-1";
if (isset($today))
  {$todays_dogs__MMColParam = $today;}
?><?php
   $todays_dogs=$ppdb->Execute("SELECT animal.*,breed.breedname  FROM animal,breed  WHERE ((thisvisit = '" . ($todays_dogs__MMColParam) . "')&&(animal.breedID=breed.breedID)) ORDER BY animalname ASC") or DIE($ppdb->ErrorMsg());
   $todays_dogs_numRows=0;
   $todays_dogs__totalRows=$todays_dogs->RecordCount();
?><?php
   $Repeat1__numRows = -1;
   $Repeat1__index= 0;
   $todays_dogs_numRows = $todays_dogs_numRows + $Repeat1__numRows;
?>


<html>
<head>
<title>Daily Totals</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>

<body>
<table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
  <tr>
    <td align="right"><?php echo date("F j, Y, g:i a"); ?></td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        
        <?php while (($Repeat1__numRows-- != 0) && (!$todays_dogs->EOF)) 
   { 
  $count++;
  $sum1 = $todays_dogs->Fields('cost');
  $sum=($sum + $sum1);
?>
        <tr>
          <td width="40%">
            <a class="medium-text" href="show_animal.php?animalID=<?php echo $todays_dogs->Fields("animalID")?>"><?php echo $todays_dogs->Fields("animalname")?></a>
          </td>
          <td width="40%">
            <?php echo $todays_dogs->Fields("breedname")?>
          </td>
          <td width="20%">
            <?php echo $todays_dogs->Fields("cost")?>
          </td>
        </tr>
        <?php
  $Repeat1__index++;
  $todays_dogs->MoveNext();
}
?>

      </table>
    </td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td width="40%">TOTAL Animals= 
            <?php echo $count;?>
             </td>
          <td width="40%" align="right">TOTAL $</td>
          <td width="20%">
            <?echo $sum;?>
          </td>
        </tr>
      </table>
      	</td>
  </tr>
  <tr>
    <td align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>
</table>
</body>
</html>
<?php
  $todays_dogs->Close();
?>
  
