<?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?><?php
// *** Insert Record: set Variables

if (isset($MM_insert)){

   // $MM_editConnection = MM_ppdb_STRING;
   $MM_editTable  = "customer";
   $MM_editRedirectUrl = "add_animal.php";
   $MM_fieldsStr = "firstname|value|surname|value|address|value|suburb|value|postcode|value|phone1|value|phone2|value|phone3|value|email|value";
   $MM_columnsStr = "firstname|',none,''|surname|',none,''|address|',none,''|suburb|',none,''|postcode|none,none,NULL|phone1|',none,''|phone2|',none,''|phone3|',none,''|email|',none,''";

  // create the $MM_fields and $MM_columns arrays
   $MM_fields = explode("|", $MM_fieldsStr);
   $MM_columns = explode("|", $MM_columnsStr);
  
  // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
 }

  // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
  }
}
?><?php
// *** Insert Record: construct a sql insert statement and execute it
if (isset($MM_insert)) {
   // create the sql insert statement
  $MM_tableValues = "";
  $MM_dbValues = "";
  for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $formVal = $MM_fields[$i+1];
    $MM_typesArray = explode(",", $MM_columns[$i+1]);
    $delim = $MM_typesArray[0];
    if($delim=="none") $delim="";
    $altVal = $MM_typesArray[1];
    if($altVal=="none") $altVal="";
    $emptyVal = $MM_typesArray[2];
    if($emptyVal=="none") $emptyVal="";
    if ($formVal == "" || !isset($formVal)) {
      $formVal = $emptyVal;
    }
    else {
      if ($altVal != "") {
        $formVal = $altVal;
      }
      else if ($delim == "'") { // escape quotes
        $formVal = $delim . $formVal . $delim;
        //$formVal = "'" . str_replace("'","\'",$formVal) . "'";
      }
      else {
        $formVal = $delim . $formVal . $delim;
      }
    }
    if ($i == 0) {
      $MM_tableValues = $MM_tableValues . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . $formVal;
    }
    else {
      $MM_tableValues = $MM_tableValues . "," . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . "," . $formVal;
    }
  }
  $MM_editQuery = "insert into " . $MM_editTable . " (" . $MM_tableValues . ") values (" . $MM_dbValues . ")";
  if ($MM_abortEdit!=1) {
    // execute the insert
    $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
	$lastID = mysql_insert_id();
    if ($MM_editRedirectUrl) {
      header ("Location: $MM_editRedirectUrl?customerID=$lastID");		
    }
  }
}
?>
<html>
<head>
<title>Add Customer</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form method="POST" action="<?php echo $MM_editAction?>" name="form1">
  <table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Firstname :</td>
            <td>
              <input class="input_field" type="text" name="firstname" size="18">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Surname :</td>
            <td>
              <input class="input_field" type="text" name="surname" value="" size="18">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text" valign="top">Address :</td>
            <td>
              <textarea class="input_fieldMultiline" name="address" cols="25" wrap="VIRTUAL" rows="3"></textarea>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Suburb :</td>
            <td>
              <input class="input_field" type="text" name="suburb" value="" size="18">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Postcode :</td>
            <td>
              <input class="input_field" type="text" name="postcode" value="" size="6" maxlength="4">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Phone1 :</td>
            <td>
              <input class="input_field" type="text" name="phone1" value="" size="18" maxlength="10">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" align="right" class="medium-text">Phone2 :</td>
            <td>
              <input class="input_field" type="text" name="phone2" size="18" maxlength="10">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" class="medium-text" align="right">Phone3 :</td>
            <td>
              <input class="input_field" type="text" name="phone3" size="18" maxlength="10">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr valign="middle">
            <td width="150" class="medium-text" align="right">Email :</td>
            <td>
              <input class="input_field" type="text" name="email" size="30" maxlength="200">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr>
            <td width="150">
              <input class="button" type="hidden" name="MM_insert" value="true">
              <input type="hidden" name="MM_insert2" value="true">
            </td>
            <td>
              <input class="button" type="submit" value="Insert Record" name="submit">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td valign="top" align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
    </tr>
    
  </table>
  <input type="hidden" name="MM_insert" value="true">
  <input type="hidden" name="MM_insert" value="true">
  
  
</form>
<p>&nbsp;</p>
</body>
</html>





  
