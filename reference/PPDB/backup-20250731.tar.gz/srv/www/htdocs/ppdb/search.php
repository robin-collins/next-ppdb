<html>
<head>
<title>Search for RECORD</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="toptpp2.css" type="text/css">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
  
<table width="640" border="0" cellspacing="0" cellpadding="0" height="85">
    
  <tr valign="top" align="center"> 
      
    <td height="34">
      <form name="form2" method="post" action="add_customer.php" target="ppbottom">
               
        <input class="button" type="submit" name="Submit" value="Add Customer">
      </form>
    </td>
    <td height="34">
      <form name="form3" method="post" action="edit_breed.php" target="_blank">
        <input class="button" type="submit" name="Submit2" value="Add Breed">
      </form>
    </td>
    <td height="34">
      <form name="form4" method="post" action="daily_totals.php" target="ppbottom">
        <input class="button" type="submit" name="Submit" value="Daily Totals">
      </form>
    </td>
    <td align="right" height="34" width="175"><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFF00"><u>
    <form name="form5" method="post" action="old_customers.php" target="ppbottom">
      <input class="button" type="submit" name="Submit" value="Old Customers">
    </form>
    <a href="backup-data.php" target="_blank">Backup Data</a><br>
    <?php echo date("F j, Y"); ?> </u></font></td>
  </tr>
  <form name="form1" method="post" action="show_search.php" target="ppbottom">
     
    <tr valign="baseline"> 
      <td  width="155" valign="bottom" align="center"> 
        <font face="Verdana, Arial, Helvetica, sans-serif">ANIMAL 
        NAME</font><br>
        </td>
      <td  width="155" valign="bottom" align="center"> 
        BREED<br>
        </td>
      <td  width="155" align="center" valign="bottom"> 
        SURNAME<br>
        </td>
      <td  align="left" valign="middle" width="175">
        <span class="smallass">DSLIP &copy; 2001</span>
      </td>
    </tr>
    <tr valign="baseline">
      <td  width="155" valign="top" align="center">
        <input class="input_field" type="text" name="s_animal" size="13">
      </td>
      <td  width="155" valign="top" align="center">
        <input class="input_field" type="text" name="s_breed" size="13">
      </td>
      <td  width="155" align="center" valign="top">
        <input class="input_field" type="text" name="s_surname" size="13">
      </td>
      <td  align="left" valign="middle" width="175">
        <input type="submit" name="submit" alt="Find the ANIMAL!!" value="Find Animal" class="button">
        <input type="reset" name="clear" value="CLEAR" class="button">
      </td>
    </tr>
  </form>
</table>

</body>
</html>
