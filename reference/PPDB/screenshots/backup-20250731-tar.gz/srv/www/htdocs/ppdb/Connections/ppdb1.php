<?php 
	# PHP ADODB document - made with PHAkt
	# FileName="Connection_php_adodb.htm"
	# Type="ADODB"
	# HTTP="true"
	# DBTYPE="mysql"
	
	$MM_ppdb1_HOSTNAME = "localhost";
	$MM_ppdb1_DATABASE = "mysql:ppdb";
	$MM_ppdb1_DBTYPE   = preg_replace("/:.*$/", "", $MM_ppdb1_DATABASE);
	$MM_ppdb1_DATABASE = preg_replace("/^.*:/", "", $MM_ppdb1_DATABASE);
	$MM_ppdb1_USERNAME = "root";
	$MM_ppdb1_PASSWORD = "6uldv8";
	$MM_ppdb1_LOCALE = "En";
	$MM_ppdb1_MSGLOCALE = "En";
	$MM_ppdb1_CTYPE = "P";
	$KT_locale = $MM_ppdb1_MSGLOCALE;
	$KT_dlocale = $MM_ppdb1_LOCALE;
	$KT_serverFormat = "%Y-%m-%d %H:%M:%S";
	$QUB_Caching = "false";
	
	switch (strtoupper ($MM_ppdb1_LOCALE)) {
		case 'EN':
				$KT_localFormat = "%d-%m-%Y %H:%M:%S";
		break;
		case 'EUS':
				$KT_localFormat = "%m-%d-%Y %H:%M:%S";
		break;
		case 'FR':
				$KT_localFormat = "%d-%m-%Y %H:%M:%S";
		break;
		case 'RO':
				$KT_localFormat = "%d-%m-%Y %H:%M:%S";
		break;
		case 'IT':
				$KT_localFormat = "%d-%m-%Y %H:%M:%S";
		break;
		case 'GE':
				$KT_localFormat = "%d-%m-%Y %H:%M:%S";
		break;
		case 'US':
				$KT_localFormat = "%Y-%m-%d %H:%M:%S";
		break;
		default :
				$KT_localFormat = "none";			
	}


	
	if (!defined('CONN_DIR')) define('CONN_DIR',dirname(__FILE__));
	require_once(CONN_DIR."/../adodb/adodb.inc.php");
	ADOLoadCode($MM_ppdb1_DBTYPE);
	$ppdb1=&ADONewConnection($MM_ppdb1_DBTYPE);

	if($MM_ppdb1_DBTYPE == "access" || $MM_ppdb1_DBTYPE == "odbc"){
		if($MM_ppdb1_CTYPE == "P"){
			$ppdb1->PConnect($MM_ppdb1_DATABASE, $MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD, 
			$MM_ppdb1_LOCALE);
		} else $ppdb1->Connect($MM_ppdb1_DATABASE, $MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD, 
			$MM_ppdb1_LOCALE);
	} else if($MM_ppdb1_DBTYPE == "ibase") {
		if($MM_ppdb1_CTYPE == "P"){
			$ppdb1->PConnect($MM_ppdb1_HOSTNAME.":".$MM_ppdb1_DATABASE,$MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD);
		} else $ppdb1->Connect($MM_ppdb1_HOSTNAME.":".$MM_ppdb1_DATABASE,$MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD);
	}else {
		if($MM_ppdb1_CTYPE == "P"){
			$ppdb1->PConnect($MM_ppdb1_HOSTNAME,$MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD,
   			$MM_ppdb1_DATABASE,$MM_ppdb1_LOCALE);
		} else $ppdb1->Connect($MM_ppdb1_HOSTNAME,$MM_ppdb1_USERNAME,$MM_ppdb1_PASSWORD,
   			$MM_ppdb1_DATABASE,$MM_ppdb1_LOCALE);
   }

	if (!function_exists("updateMagicQuotes")) {
		function updateMagicQuotes($HTTP_VARS){
			if (is_array($HTTP_VARS)) {
				foreach ($HTTP_VARS as $name=>$value) {
					if (!is_array($value)) {
						$HTTP_VARS[$name] = addslashes($value);
					} else {
						foreach ($value as $name1=>$value1) {
							if (!is_array($value1)) {
								$HTTP_VARS[$name1][$value1] = addslashes($value1);
							}
						}
						
					}
					global $$name;
					$$name = &$HTTP_VARS[$name];
				}
			}
			return $HTTP_VARS;
		}
		
		if (!get_magic_quotes_gpc()) {
			$_GET = updateMagicQuotes($_GET);
			$_POST = updateMagicQuotes($_POST);
			$_COOKIE = updateMagicQuotes($_COOKIE);
		}
	}
?>
