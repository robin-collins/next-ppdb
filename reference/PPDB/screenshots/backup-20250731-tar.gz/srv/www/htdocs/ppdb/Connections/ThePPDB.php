<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_ThePPDB = "localhost";
$database_ThePPDB = "ppdb";
$username_ThePPDB = "root";
$password_ThePPDB = "6uldv8";
$ThePPDB = mysql_pconnect($hostname_ThePPDB, $username_ThePPDB, $password_ThePPDB) or trigger_error(mysql_error(),E_USER_ERROR); 
?>