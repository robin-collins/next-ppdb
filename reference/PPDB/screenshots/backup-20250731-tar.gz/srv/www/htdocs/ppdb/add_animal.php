<?php 
if (isset($lastvisit))
  {
  $newlast = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $lastvisit);
  $lastvisit = $newlast;
  }
if (isset($thisvisit))
  {
  $newthis = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $thisvisit);
  $thisvisit = $newthis;
  }

if ($customerID) {$lastID = $customerID;}

?><?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?><?php
// *** Insert Record: set Variables

if (isset($MM_insert)){

   // $MM_editConnection = MM_ppdb_STRING;
   $MM_editTable  = "animal";
   $MM_editRedirectUrl = "show_animal.php";
   $MM_fieldsStr = "animalname|value|breedID|value|customerID|value|SEX|value|colour|value|cost|value|lastvisit|value|thisvisit|value|comments|value";
   $MM_columnsStr = "animalname|',none,''|breedID|none,none,NULL|customerID|none,none,NULL|SEX|',none,''|colour|',none,''|cost|none,none,NULL|lastvisit|',none,NULL|thisvisit|',none,NULL|comments|',none,''";

  // create the $MM_fields and $MM_columns arrays
   $MM_fields = explode("|", $MM_fieldsStr);
   $MM_columns = explode("|", $MM_columnsStr);
  
  // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
 }

  // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
  }
}
?><?php
// *** Insert Record: construct a sql insert statement and execute it
if (isset($MM_insert)) {
   // create the sql insert statement
  $MM_tableValues = "";
  $MM_dbValues = "";
  for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $formVal = $MM_fields[$i+1];
    $MM_typesArray = explode(",", $MM_columns[$i+1]);
    $delim = $MM_typesArray[0];
    if($delim=="none") $delim="";
    $altVal = $MM_typesArray[1];
    if($altVal=="none") $altVal="";
    $emptyVal = $MM_typesArray[2];
    if($emptyVal=="none") $emptyVal="";
    if ($formVal == "" || !isset($formVal)) {
      $formVal = $emptyVal;
    }
    else {
      if ($altVal != "") {
        $formVal = $altVal;
      }
      else if ($delim == "'") { // escape quotes
        $formVal = $delim . $formVal . $delim;
        //$formVal = "'" . str_replace("'","\'",$formVal) . "'";
      }
      else {
        $formVal = $delim . $formVal . $delim;
      }
    }
    if ($i == 0) {
      $MM_tableValues = $MM_tableValues . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . $formVal;
    }
    else {
      $MM_tableValues = $MM_tableValues . "," . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . "," . $formVal;
    }
  }
  $MM_editQuery = "insert into " . $MM_editTable . " (" . $MM_tableValues . ") values (" . $MM_dbValues . ")";
  if ($MM_abortEdit!=1) {
    // execute the insert
    $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
	$insertid= mysql_insert_id();
    header ("Location: show_animal.php?animalID=$insertid");		
    
  }
}
?><?php
$customer__MMColParam = "-1";
if (isset($lastID))
  {$customer__MMColParam = $lastID;}
?><?php
   $customer=$ppdb->Execute("SELECT * FROM customer WHERE customerID = " . ($customer__MMColParam) . "") or DIE($ppdb->ErrorMsg());
   $customer_numRows=0;
   $customer__totalRows=$customer->RecordCount();
?><?php
   $all_breeds=$ppdb->Execute("SELECT * FROM breed ORDER BY breedname ASC") or DIE($ppdb->ErrorMsg());
   $all_breeds_numRows=0;
   $all_breeds__totalRows=$all_breeds->RecordCount();
?><?php
   $Repeat1__numRows = -1;
   $Repeat1__index= 0;
   $all_breeds_numRows = $all_breeds_numRows + $Repeat1__numRows;
?>


<html>
<head>
<title>Add Animal -       
<?php echo $customer->Fields("firstname")?>
      
<?php echo $customer->Fields("surname")?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">



<script LANGUAGE="JavaScript" SRC="dateslib.js"></script>
<script LANGUAGE="JavaScript" SRC="calendar.js"></script>
<SCRIPT LANGUAGE=javascript>
<!--
function lastvisit_onclick() {
	DateDialogClick(document.form1.lastvisit);
}
function thisvisit_onclick() {
	DateDialogClick(document.form1.thisvisit);
}

// -->
</SCRIPT>
<script language="JavaScript">
<!--
//fully netscape compliant
function setCost() {
var X = new Array();
<?php while (($Repeat1__numRows-- != 0) && (!$all_breeds->EOF)) 
   { 
?>
X[<?php echo $all_breeds->Fields(breedID); ?>] = "<?php echo $all_breeds->Fields(avgcost); ?>";
<?php
  $Repeat1__index++;
  $all_breeds->MoveNext();
}
?>

	document.form1.cost.value = X[document.form1.breedID.options[document.form1.breedID.selectedIndex].value];
}
// -->
</script>




</head>

<body>
<table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033" align="left">
  <tr>
    <td bgcolor="#000033">
      <?php echo $customer->Fields("firstname")?>
      <?php echo $customer->Fields("surname")?>
- 
      <?php echo $customer->Fields("phone1")?>
                </td>
  </tr>
  <tr>
    <td>
	
	  <form method="POST" action="<?php echo $MM_editAction?>" name="form1">
      
    
        <table border=0 cellpadding=2 cellspacing=0 align="left" width="100%">
      
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Animal Name:</td>
            <td width="65%">
              
                
              <input class="input_field" type="text" name="animalname" size="18" style="medium-text">
  </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Breed:</td>
            <td width="65%">
              
                
              <select class="input_field" name="breedID" onChange="setCost();return false;">
                  
                <?php
  if ($all_breeds__totalRows > 0){
    $all_breeds__index=0;
    $all_breeds->MoveFirst();
    WHILE ($all_breeds__index < $all_breeds__totalRows){
?>
                  
                <OPTION VALUE="<?php echo $all_breeds->Fields("breedID")?>">
                  
                <?php echo $all_breeds->Fields("breedname");?>
          </OPTION>
                  
                <?php
      $all_breeds->MoveNext();
      $all_breeds__index++;
    }
    $all_breeds__index=0;  
    $all_breeds->MoveFirst();
  }
?>
                
              </select>
                
              <input class="input_field" type="hidden" name="customerID" value="<?php echo $customer->Fields("customerID")?>">
                
              <input class="input_field" type="hidden" name="MM_insert" value="true">
          </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Sex:</td>
            <td width="65%">
              
                
              <select class="input_field"  name="SEX">
                  
                <option value="Male">Male</option>
                  
                <option value="Female">Female</option>
                
              </select>
        </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Colour:</td>
            <td width="65%">
              
                
              <input class="input_field" type="text" name="colour" value="" size="18">
  </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Cost ($):</td>
            <td width="65%">
              
                
              <input class="input_field" type="text" name="cost" value="55" size="5">
  </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Last Visit:
            </td>
            <td width="65%">
              
                
              <input class="input_field" type="text" name="lastvisit" size="13" value="<?php $today = mktime(0,0,0,date("m"),date("d"),date("Y")); echo date('j-m-Y',($today-3628800));?>">
		        
              <input class="calendar" type="button" name="lastvisit1" value="..." LANGUAGE=javascript onclick="return lastvisit_onclick()">
              </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              This Visit:<br>
          </td>
            <td width="65%">
              
                
              <input class="input_field" type="text" name="thisvisit" value="<?php echo date('j-m-Y'); ?>" size="13">
                
              <input class="calendar" type="button" name="thisvisit1" value="..." language=javascript onClick="return thisvisit_onclick()">
              </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">
              Comments:</td>
            <td width="65%">
              
                
              <textarea name="comments" cols="25" wrap="VIRTUAL" rows="4"></textarea>
  </td>
          </tr>
  
          <tr valign="top" align="left">
            <td nowrap align="right" class="medium-text" width="35%">&nbsp;
              </td>
            <td width="65%">
              
                
              <input class="button" type="submit" value="Insert Record" name="submit">
  </td>
          </tr>
  
    
        </table>
      </form>
    </td>
  </tr>
  <tr>
    <td valign="top" align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>
</table>
</body>
</html>
<?php
  $customer->Close();
?>
<?php
  $all_breeds->Close();
?>
  
  
