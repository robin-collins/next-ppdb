<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript"></script>
<script language="JavaScript" src="scripts/behActions.js"></script>
<script language="JavaScript" src="scripts/behCourseBuilder.js"></script>
<script language="JavaScript" src="scripts/interactionClass.js"></script>
<script language="JavaScript" src="scripts/elemIbtnClass.js"></script>
</head>

<body bgcolor="#FFFFFF" text="#000000" onLoad="MM_initInteractions()">
<interaction name="MultCh_ImageChkboxes01" object="G01" template="010_Multiple Choice/060_MultCh_ImageChkboxes_04.agt" includesrc="interactionClass.js,elemIbtnClass.js"> 
<div name="G01Layer"> <span name="G01question">What colour is a lemon: <br>
  </span> 
  <form name="G01choices">
    <span name="G01choice1"> <a name="G01choice1Inp" href="#"
      onClick="G01.e['choice1'].update('onclick');return false"
      onMouseOver="G01.e['choice1'].update('onmouseover');"
      onMouseOut="G01.e['choice1'].update('onmouseout');"
      onMouseDown="G01.e['choice1'].update('onmousedown');"> <img name="G01choice1Btn" src="images/buttons/checkbox_red.gif" border=0 align="absbottom"></a> 
    blue<br>
    </span> <span name="G01choice2"> <a name="G01choice2Inp" href="#"
      onClick="G01.e['choice2'].update('onclick');return false"
      onMouseOver="G01.e['choice2'].update('onmouseover');"
      onMouseOut="G01.e['choice2'].update('onmouseout');"
      onMouseDown="G01.e['choice2'].update('onmousedown');"> <img name="G01choice2Btn" src="images/buttons/checkbox_red.gif" border=0 align="absbottom"></a> 
    orange<br>
    </span> <span name="G01choice3"> <a name="G01choice3Inp" href="#"
      onClick="G01.e['choice3'].update('onclick');return false"
      onMouseOver="G01.e['choice3'].update('onmouseover');"
      onMouseOut="G01.e['choice3'].update('onmouseout');"
      onMouseDown="G01.e['choice3'].update('onmousedown');"> <img name="G01choice3Btn" src="images/buttons/checkbox_red.gif" border=0 align="absbottom"></a> 
    green<br>
    </span> <span name="G01choice4"> <a name="G01choice4Inp" href="#"
      onClick="G01.e['choice4'].update('onclick');return false"
      onMouseOver="G01.e['choice4'].update('onmouseover');"
      onMouseOut="G01.e['choice4'].update('onmouseout');"
      onMouseDown="G01.e['choice4'].update('onmousedown');"> <img name="G01choice4Btn" src="images/buttons/checkbox_red.gif" border=0 align="absbottom"></a> 
    yellow<br>
    </span> 
  </form>
  <form name="G01controls">
    <input name="G01judge" type="button" value="Submit" onClick="MM_judgeInt('G01')">
    <input name="G01reset" type="button" value="Reset" onClick="MM_resetInt('G01','reset','')">
  </form>
</div>
<script language="JavaScript">
<!--
  // Copyright 1998,1999 Macromedia, Inc. All rights reserved.
  function newG01() {
    G01 = new MM_interaction('G01',0,1,1,null,0,0,0,'','','c','',0);
    G01.add('ibtn','choice1',0,1,1,0,1,'sdhSDH');
    G01.add('ibtn','choice2',0,1,1,0,1,'sdhSDH');
    G01.add('ibtn','choice3',0,1,0,0,1,'sdhSDH');
    G01.add('ibtn','choice4',0,1,0,0,1,'sdhSDH');
    G01.init();
    G01.am('segm','Segment: Check Time_',1,1);
    G01.am('cond','Time At Limit_','G01.timeAtLimit == true',0);
    G01.am('actn','Popup Message','MM_popupMsg(\'You are out of time\')','pm');
    G01.am('actn','Set Interaction Properties: Disable Interaction','MM_setIntProps(\'G01.setDisabled(true);\')','sp');
    G01.am('end');
    G01.am('segm','Segment: Correctness_',1,0);
    G01.am('cond','Correct_01','G01.correct == true',0);
    G01.am('actn','Popup Message','MM_popupMsg(\'Correct\')','');
    G01.am('end');
    G01.am('cond','Incorrect_','G01.correct == (false)',0);
    G01.am('actn','Popup Message','MM_popupMsg(\'Incorrect\')','');
    G01.am('end');
    G01.am('cond','Unknown Response_','G01.knownResponse == false',0);
    G01.am('actn','Popup Message','MM_popupMsg(\'Unknown Response\')','');
    G01.am('end');
    G01.am('segm','Segment: Check Tries_',1,1);
    G01.am('cond','Tries At Limit_','G01.triesAtLimit == true',0);
    G01.am('actn','Popup Message','MM_popupMsg(\'You are out of tries\')','pm');
    G01.am('actn','Set Interaction Properties: Disable Interaction','MM_setIntProps(\'G01.setDisabled(true);\')','sp');
    G01.am('end');
  }
  if (window.newG01 == null) window.newG01 = newG01;
  if (!window.MM_initIntFns) window.MM_initIntFns = ''; window.MM_initIntFns += 'newG01();';
//-->
</script>
<cbi-select object="G01"></interaction> 
</body>
</html>
