<?php
// configuration file to be included in all new documents.

$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_password = '6uldv8';
$mysql_db = 'ppdb';

function open_db() {
  global $mysql_host, $mysql_user, $mysql_password, $mysql_db, $db_link;
  $db_link = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die('Could Not connect: '. mysql_error());
  $db = mysql_select_db($mysql_db) or die('Could not select database');
  }

function query_db($query) {
  $result = mysql_query($query) or die('Query failed: ' . mysql_error());
  return $result;
  }

function close_db() {
  global $mysql_host, $mysql_user, $mysql_password, $mysql_db, $db_link;
  mysql_close($db_link);
  }



/*
// Connecting, selecting database
$link = mysql_connect('mysql_host', 'mysql_user', 'mysql_password')
    or die('Could not connect: ' . mysql_error());
echo 'Connected successfully';
mysql_select_db('my_database') or die('Could not select database');

// Performing SQL query
$query = 'SELECT * FROM my_table';
$result = mysql_query($query) or die('Query failed: ' . mysql_error());

// Printing results in HTML
echo "<table>\n";
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

// Free resultset
mysql_free_result($result);

// Closing connection
mysql_close($link);


*/

?>