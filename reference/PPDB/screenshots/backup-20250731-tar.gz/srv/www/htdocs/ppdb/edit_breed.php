<?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?><?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?><?php
  // *** Update Record: set variables
  
  if (isset($MM_update) && (isset($MM_recordId))) {
  
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "breed";
    $MM_editColumn = "breedID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "edit_breed.php";
    $MM_fieldsStr = "breedname|value|breedID|value|avgtime|value|avgcost|value";
    $MM_columnsStr = "breedname|',none,''|breedID|none,none,NULL|avgtime|',none,''|avgcost|none,none,NULL";
  
    // create the $MM_fields and $MM_columns arrays
   $MM_fields = Explode("|", $MM_fieldsStr);
   $MM_columns = Explode("|", $MM_columnsStr);
    
    // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
    }
  
    // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
  ?><?php
  // *** Delete Record: declare variables
  if (isset($MM_delete) && (isset($MM_recordId))) {
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "breed";
    $MM_editColumn = "breedID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "edit_breed.php";
  
    if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
      $MM_editRedirectUrl = $MM_editRedirectUrl . ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
?><?php
// *** Insert Record: set Variables

if (isset($MM_insert)){

   // $MM_editConnection = MM_ppdb_STRING;
   $MM_editTable  = "breed";
   $MM_editRedirectUrl = "edit_breed.php";
   $MM_fieldsStr = "breedname|value|avgtime|value|avgcost|value";
   $MM_columnsStr = "breedname|',none,''|avgtime|',none,NULL|avgcost|none,none,NULL";

  // create the $MM_fields and $MM_columns arrays
   $MM_fields = explode("|", $MM_fieldsStr);
   $MM_columns = explode("|", $MM_columnsStr);
  
  // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
 }

  // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
  }
}
?><?php
  // *** Update Record: construct a sql update statement and execute it
  
 if (isset($MM_update) && (isset($MM_recordId))) {
  
	// create the sql update statement
	$MM_editQuery = "update " . $MM_editTable . " set ";
	for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) 
	{
		$formVal = $MM_fields[$i+1];
		$MM_typesArray = Explode(",", $MM_columns[$i+1]);
		$delim =    ($MM_typesArray[0] != "none") ? $MM_typesArray[0] : "";
		$altVal =   ($MM_typesArray[1] != "none") ? $MM_typesArray[1] : "";
		$emptyVal = ($MM_typesArray[2] != "none") ? $MM_typesArray[2] : "";
		if ($formVal == "" || !isset($formVal)) 
		{
			$formVal = $emptyVal;
		} 
		else 
		{
			if ($altVal != "") 
			{
				$formVal = $altVal;
			} 
			else if ($delim == "'") 
			{ // do not escape quotes in PHP4
				$formVal = "'" .$formVal . "'";
			} 
			else 
			{
				$formVal = $delim . $formVal . $delim;
			}
		}
		if ($i != 0)
			{
				$MM_editQuery = $MM_editQuery . ", " . $MM_columns[$i] . " = " . $formVal;
			}
			else
			{
				$MM_editQuery = $MM_editQuery . $MM_columns[$i] . " = " . $formVal;
			}
		}

	$MM_editQuery = $MM_editQuery . " where " . $MM_editColumn . " = " . $MM_recordId;

	if ($MM_abortEdit != 1)
	{
		// execute the insert
		$queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
		if ($MM_editRedirectUrl) 
		{
			header ("Location: $MM_editRedirectUrl");
		}		 
	}
}
?><?php
  // *** Delete Record: construct a sql delete statement and execute it
  if (isset($MM_delete) && (isset($MM_recordId))) {
    $MM_editQuery = "delete from " . $MM_editTable . " where " . $MM_editColumn . " = " . $MM_recordId;
    if ($MM_abortEdit!=1) {
      $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
      if ($MM_editRedirectUrl) {
        header ("Location: $MM_editRedirectUrl");
      }		 
    }
  }
?><?php
// *** Insert Record: construct a sql insert statement and execute it
if (isset($MM_insert)) {
   // create the sql insert statement
  $MM_tableValues = "";
  $MM_dbValues = "";
  for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $formVal = $MM_fields[$i+1];
    $MM_typesArray = explode(",", $MM_columns[$i+1]);
    $delim = $MM_typesArray[0];
    if($delim=="none") $delim="";
    $altVal = $MM_typesArray[1];
    if($altVal=="none") $altVal="";
    $emptyVal = $MM_typesArray[2];
    if($emptyVal=="none") $emptyVal="";
    if ($formVal == "" || !isset($formVal)) {
      $formVal = $emptyVal;
    }
    else {
      if ($altVal != "") {
        $formVal = $altVal;
      }
      else if ($delim == "'") { // escape quotes
        $formVal = $delim . $formVal . $delim;
        //$formVal = "'" . str_replace("'","\'",$formVal) . "'";
      }
      else {
        $formVal = $delim . $formVal . $delim;
      }
    }
    if ($i == 0) {
      $MM_tableValues = $MM_tableValues . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . $formVal;
    }
    else {
      $MM_tableValues = $MM_tableValues . "," . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . "," . $formVal;
    }
  }
  $MM_editQuery = "insert into " . $MM_editTable . " (" . $MM_tableValues . ") values (" . $MM_dbValues . ")";
  if ($MM_abortEdit!=1) {
    // execute the insert
    $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
    if ($MM_editRedirectUrl) {
      header ("Location: $MM_editRedirectUrl");		
    }
  }
}
?><?php
   $All_breeds=$ppdb->Execute("SELECT * FROM breed ORDER BY breedname ASC") or DIE($ppdb->ErrorMsg());
   $All_breeds_numRows=0;
   $All_breeds__totalRows=$All_breeds->RecordCount();
?><?php
   $Repeat1__numRows = -1;
   $Repeat1__index= 0;
   $All_breeds_numRows = $All_breeds_numRows + $Repeat1__numRows;
?>

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>

<body>
<table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
  <tr>
    <td>
      <form method="post" action="<?php echo $MM_editAction?>" name="form3">
      
        <table border=0 cellpadding=2 cellspacing=0 align="center">
      
          <tr valign="baseline">
            <td nowrap align="right">Breed:</td>
            <td>
              <input class="input_field" type="text" name="breedname" value="" size="32">
  </td>
          </tr>
  
          <tr valign="baseline">
            <td nowrap align="right">Avg. Time:</td>
            <td>
              <input class="input_field" type="text" name="avgtime" value="" size="32">
  </td>
          </tr>
  
          <tr valign="baseline">
            <td nowrap align="right">Avg. Cost:</td>
            <td>
              <input class="input_field" type="text" name="avgcost" value="" size="32">
  </td>
          </tr>
  
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td>
              <input class="button" type="submit" value="Insert Record" name="submit">
  </td>
          </tr>
  
        </table>
        <input class="input_field" type="hidden" name="MM_insert" value="true">
      </form>
    </td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr align="center" valign="top">
          <td width="180">BREED</td>
          <td width="80">TIME</td>
          <td width="80">COST</td>
          <td width="150">&nbsp;</td>
          <td width="150">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
  
  <?php while (($Repeat1__numRows-- != 0) && (!$All_breeds->EOF)) 
   { 
?>
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr align="center" valign="middle">
	      <form name="form1" method="POST" action="<?php echo $MM_editAction?>">
            <td width="180" class="medium-text">
            
              <input class="input_field" type="text" name="breedname" size="18" value="<?php echo $All_breeds->Fields("breedname")?>">
              <input class="input_field" type="hidden" name="breedID" value="<?php echo $All_breeds->Fields("breedID")?>">
                        </td>
            <td width="80" class="medium-text">
            
              <input class="input_field" type="text" name="avgtime" value="<?php echo $All_breeds->Fields("avgtime")?>" size="5">
            </td>
            <td width="80" class="medium-text">
            
              <input class="input_field" type="text" name="avgcost" size="5" value="<?php echo $All_breeds->Fields("avgcost")?>">
            </td>
            <td width="150" class="medium-text">
              <input class="button" type="submit" name="Submit" value="Update">
            </td>
            <input class="input_field" type="hidden" name="MM_update" value="true">
  
            <input class="input_field" type="hidden" name="MM_recordId" value="<?php echo $All_breeds->Fields("breedID") ?>">
          </form>
          <form name="form2" method="POST" action="<?php echo $MM_editAction?>">

            <td width="150" class="medium-text">
              <input class="button" type="submit" name="Submit" value="Delete">
              <input class="input_field" type="hidden" name="breedID" value="<?php echo $All_breeds->Fields("breedID")?>">
            </td>
            <input class="input_field" type="hidden" name="MM_delete" value="true">
  
            <input class="input_field" type="hidden" name="MM_recordId" value="<?php echo $All_breeds->Fields("breedID") ?>">
          </form>
        </tr>
      </table>
      	</td>
  </tr>
  <?php
  $Repeat1__index++;
  $All_breeds->MoveNext();
}
?>
  <tr>
    <td align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>


</table>
</body>
</html>
<?php
  $All_breeds->Close();
?>