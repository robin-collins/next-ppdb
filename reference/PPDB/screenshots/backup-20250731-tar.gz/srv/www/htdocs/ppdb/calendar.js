var winModalWindow;
var gcModalDialogURL = "calendar.html";
var gcModalDialogName = "Calendar";

function ShowCalendar(ParamPassed)
{
	var r;
	var featuresString;
	if (document.all) {
		if (document.getElementById) {
			featuresString = "dialogHeight:225px;dialogWidth:220px;scroll:no;status:no;toolbar:no";
		}
		else
		{	
			featuresString = "dialogHeight:245px;dialogWidth:220px;scroll:no";
		}
		r = window.showModalDialog(gcModalDialogURL, 
							(typeof(ParamPassed)=="undefined" || ParamPassed=="")?
							"blank":ParamPassed, featuresString);
		return r;
	}
	else {
		alert("This feature is only available in Internet Explorer 4 and above at this stage.");
	}
}

function DateDialogClick(TheTextBox) {
	var r = new String();
	var D = new Date();
	var s;
	if (TheTextBox.value == "") {                       ///XXXX needs alpha value 
		r = TheTextBox.value;	// get string value
	} else {
		r = Transform(TheTextBox.value);	// get string value
	}
	D = r.AsDate();						// convert to date
	
	if (navigator.appName=="Netscape"){		//NS
		s=window.prompt("Please enter a date in the format dd mmm yyyy", D.Format(""));
		if (s!=null){
			TheTextBox.value = s;
			return true;
		}
	}
	else {				// IE
		// the modal screen always returns a string (the locale date string)
		r = ShowCalendar(D.Format(""));// and pass as locale string to modal screen
		if (typeof(r)=="undefined") r="";	// make string to avoid error on next line
		if (r.isDate()) {
			D.setTime(Date.parse(r));		// convert date string to date variable
			TheTextBox.value = D.Format("",1);
			return true;
		}
		else {
			return false;					// no date returned 
		}
	}
}

function Transform(dateString) {

	var i=0;
	var Months = new Array("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
	var delim = "";
	var day = "";
	var month = "";
	var year = "";
	var spaces = 0;
	var init = 0;
	var s=dateString; 

		if (s == "" ) {
			return s;
		}
		for (i;i<Months.length;i++) {
			if (s.lastIndexOf(Months[i])!= -1) {
				 return s;
			}
		}
		i=0;
		while (i < s.length) {
			if (s.charAt(i) == ' ') {
				i=i+1;
			} else {
				break;
			}
		}
		while(!isNaN(s.charAt(i)) && i < s.length ) {
			day = day + s.charAt(i);
			i=i+1;
		}
		if (i < s.length) {
			delim = s.charAt(i);
			i=i+1;
		}
		while(!isNaN(s.charAt(i)) && i < s.length ) {
			month = month + s.charAt(i);
			i=i+1;
		}
		i=i+1; //assumes delimiter
		while(!isNaN(s.charAt(i)) && i < s.length ) {
			year = year + s.charAt(i);
			i=i+1;
		}
		if(!isNaN(year) && year < 100) {
			if (year < 50) {
				year = parseInt(year) + parseInt(2000);				
			} else { 
				year = parseInt(year) + parseInt(1900);
			}
		}	
		return month + "-" + day + "-" + year;
}//Transform()

