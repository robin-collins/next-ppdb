<?php
// Legacy includes for MySQL access
  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");

// get the post vars.
?>

<?php
 if (isset($s_surname)) {
 if ($s_surname && strlen($s_surname)>0) {
	 $surname_SQL = "(`customer`.`surname` LIKE \"".$s_surname."%\")"; }
 else {
   $surname_SQL = ""; }
  }

 if (isset($s_animal)) {
 if ($s_animal && strlen($s_animal)>0) {
   $animal_SQL = "(`animal`.`animalname` LIKE \"".$s_animal."%\")"; }
 else {
   $animal_SQL = ""; }
}

 if (isset($s_breed)) {
 if ($s_breed && strlen($s_breed)>0) {
   $breed_SQL = "(`breed`.`breedname` LIKE \"".$s_breed."%\")"; }
 else {
   $breed_SQL = ""; }
}

if (isset($s_animal)||isset($s_breed)||isset($s_surname)) {
 if ((strlen($s_animal)>0)||(strlen($s_breed)>0)||(strlen($s_surname)>0)) {
	 $s_SQL = "WHERE (";
	 $sqlcounter =0;
	 if ($animal_SQL !="") { $s_SQL .= $animal_SQL; $sqlcounter++;}
	 if (($sqlcounter ==1)&&($surname_SQL !="")) { $s_SQL .= "&&"; $sqlcounter = 0; }
	 if ($surname_SQL !="") { $s_SQL .= $surname_SQL; $sqlcounter++; }
	 if (($sqlcounter ==1)&&($breed_SQL !="")) { $s_SQL .= "&&"; $sqlcounter = 0; }
	 if ($breed_SQL !="") { $s_SQL .= $breed_SQL; }
	 $s_SQL .= ") ORDER BY `animal`.`animalname` ASC"; }
 else {
   $s_SQL = "ORDER BY `animal`.`animalname` ASC"; }
}

 ?><?php
$search__MMColParam = "-1";
if (isset($s_SQL))
  {$search__MMColParam = $s_SQL;}
?><?php
   $search=$ppdb->Execute("SELECT customer.customerID, customer.surname, customer.firstname, animal.animalID, animal.animalname, animal.colour, breed.breedname  FROM (animal RIGHT JOIN customer ON animal.customerID = customer.customerID) LEFT JOIN breed ON animal.breedID = breed.breedID  " . ($search__MMColParam) . "") or DIE($ppdb->ErrorMsg());
   $search_numRows=0;
   $search__totalRows=$search->RecordCount();
?><?php
   $Repeat1__numRows = 20;
   $Repeat1__index= 0;
   $search_numRows = $search_numRows + $Repeat1__numRows;
?><?php
  // *** Recordset Stats, Move To Record, and Go To Record: declare stats variables
  
  // set the record count
  $search_total = $search->RecordCount();
  
  // set the number of rows displayed on this page
  if ($search_numRows < 0) {            // if repeat region set to all records
    $search_numRows = $search_total;
  } else if ($search_numRows == 0) {    // if no repeat regions
    $search_numRows = 1;
  }
  
  // set the first and last displayed record
  $search_first = 1;
  $search_last  = $search_first + $search_numRows - 1;
  
  // if we have the correct record count, check the other stats
  if ($search_total != -1) {
    $search_numRows = min($search_numRows, $search_total);
    $search_first  = min($search_first, $search_total);
    $search_last  = min($search_last, $search_total);
  }
  ?><?php
  // *** Recordset Stats: if we don't know the record count, manually count them
 
     // set the number of rows displayed on this page
    if ($search_numRows < 0 || $search_numRows > $search_total) {
      $search_numRows = $search_total;
    }
  
    // set the first and last displayed record
   $search_last  = min($search_first + $search_numRows - 1, $search_total);
    $search_first = min($search_first, $search_total);
?><?php $MM_paramName = ""; ?><?php
// *** Move To Record and Go To Record: declare variables

$MM_rs	  = &$search;
$MM_rsCount   = $search_total;
$MM_size      = $search_numRows;
$MM_uniqueCol = "";
$MM_paramName = "";
$MM_offset = 0;
$MM_atTotal = false;
$MM_paramIsDefined = ($MM_paramName != "" && isset($$MM_paramName));
?><?php
// *** Move To Record: handle 'index' or 'offset' parameter

if (!$MM_paramIsDefined && $MM_rsCount != 0) {

	// use index parameter if defined, otherwise use offset parameter
	if(isset($index)){
		$r = $index;
	} else {
		if(isset($offset)) {
			$r = $offset;
		} else {
			$r = 0;
		}
	}
	$MM_offset = $r;

	// if we have a record count, check if we are past the end of the recordset
	if ($MM_rsCount != -1) {
		if ($MM_offset >= $MM_rsCount || $MM_offset == -1) {  // past end or move last
			if (($MM_rsCount % $MM_size) != 0) {  // last page not a full repeat region
				$MM_offset = $MM_rsCount - ($MM_rsCount % $MM_size);
			}
			else {
				$MM_offset = $MM_rsCount - $MM_size;
			}
		}
	}

	// move the cursor to the selected record
	for ($i=0;!$MM_rs->EOF && ($i < $MM_offset || $MM_offset == -1); $i++) {
		$MM_rs->MoveNext();
	}
	if ($MM_rs->EOF) $MM_offset = $i;  // set MM_offset to the last possible record
}
?><?php
// *** Move To Record: if we dont know the record count, check the display range

if ($MM_rsCount == -1) {

  // walk to the end of the display range for this page
  for ($i=$MM_offset; !$MM_rs->EOF && ($MM_size < 0 || $i < $MM_offset + $MM_size); $i++) {
    $MM_rs->MoveNext();
  }

  // if we walked off the end of the recordset, set MM_rsCount and MM_size
  if ($MM_rs->EOF) {
    $MM_rsCount = $i;
    if ($MM_size < 0 || $MM_size > $MM_rsCount) $MM_size = $MM_rsCount;
  }

  // if we walked off the end, set the offset based on page size
  if ($MM_rs->EOF && !$MM_paramIsDefined) {
    if (($MM_rsCount % $MM_size) != 0) {  // last page not a full repeat region
      $MM_offset = $MM_rsCount - ($MM_rsCount % $MM_size);
    } else {
      $MM_offset = $MM_rsCount - $MM_size;
    }
  }

  // reset the cursor to the beginning
  $MM_rs->MoveFirst();

  // move the cursor to the selected record
  for ($i=0; !$MM_rs->EOF && $i < $MM_offset; $i++) {
    $MM_rs->MoveNext();
  }
}
?><?php
// *** Move To Record: update recordset stats

// set the first and last displayed record
$search_first = $MM_offset + 1;
$search_last  = $MM_offset + $MM_size;
if ($MM_rsCount != -1) {
  $search_first = $search_first<$MM_rsCount?$search_first:$MM_rsCount;
  $search_last  = $search_last<$MM_rsCount?$search_last:$MM_rsCount;
}

// set the boolean used by hide region to check if we are on the last record
$MM_atTotal = ($MM_rsCount != -1 && $MM_offset + $MM_size >= $MM_rsCount);
?><?php
// *** Go To Record and Move To Record: create strings for maintaining URL and Form parameters

// create the list of parameters which should not be maintained
$MM_removeList = "&index=";
if ($MM_paramName != "") $MM_removeList .= "&".strtolower($MM_paramName)."=";
$MM_keepURL="";
$MM_keepForm="";
$MM_keepBoth="";
$MM_keepNone="";

// add the URL parameters to the MM_keepURL string
reset ($_GET);

while (list ($key, $val) = each ($_GET)) {
	$nextItem = "&".strtolower($key)."=";
	if (!stristr($MM_removeList, $nextItem)) {
		$MM_keepURL .= "&".$key."=".urlencode($val);
	}
}

// add the URL parameters to the MM_keepURL string
if(isset($_POST)){
	reset ($_POST);
	while (list ($key, $val) = each ($_POST)) {
		$nextItem = "&".strtolower($key)."=";
		if (!stristr($MM_removeList, $nextItem)) {
			$MM_keepForm .= "&".$key."=".urlencode($val);
		}
	}
}

// create the Form + URL string and remove the intial '&' from each of the strings
$MM_keepBoth = $MM_keepURL."&".$MM_keepForm;
if (strlen($MM_keepBoth) > 0) $MM_keepBoth = substr($MM_keepBoth, 1);
if (strlen($MM_keepURL) > 0)  $MM_keepURL = substr($MM_keepURL, 1);
if (strlen($MM_keepForm) > 0) $MM_keepForm = substr($MM_keepForm, 1);
?><?php
// *** Move To Record: set the strings for the first, last, next, and previous links

$MM_moveFirst="";
$MM_moveLast="";
$MM_moveNext="";
$MM_movePrev="";
$MM_keepMove = $MM_keepBoth;  // keep both Form and URL parameters for moves
$MM_moveParam = "index";

// if the page has a repeated region, remove 'offset' from the maintained parameters
if ($MM_size > 1) {
  $MM_moveParam = "offset";
  if (strlen($MM_keepMove)> 0) {
    $params = explode("&", $MM_keepMove);
    $MM_keepMove = "";
    for ($i=0; $i < sizeof($params); $i++) {
      list($nextItem) = explode("=", $params[$i]);
      if (strtolower($nextItem) != $MM_moveParam)  {
        $MM_keepMove.="&".$params[$i];
      }
    }
    if (strlen($MM_keepMove) > 0) $MM_keepMove = substr($MM_keepMove, 1);
  }
}

// set the strings for the move to links
if (strlen($MM_keepMove) > 0) $MM_keepMove.="&";
$urlStr = $PHP_SELF."?".$MM_keepMove.$MM_moveParam."=";
$MM_moveFirst = $urlStr."0";
$MM_moveLast  = $urlStr."-1";
$MM_moveNext  = $urlStr.($MM_offset + $MM_size);
$MM_movePrev  = $urlStr.(max($MM_offset - $MM_size,0));
?>
<html>
<head>
<title>Show_search</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<table width="640" border="1" cellspacing="0" cellpadding="0" bordercolor="#000033">
  <tr> 
    <td class="medium-text"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr bgcolor="#000033"> 
          <td class="medium-text" width="100" align="left"> <A HREF="<?php echo $MM_movePrev?>">&lt;-Prev 
            20</A>&nbsp; </td>
          <td width="440" class="medium-text" align="center">&nbsp;Dogs 
            <?php echo $search_first?>
            - 
            <?php echo $search_last?>
            of 
            <?php echo $search_total?>
            TOTAL </td>
          <td class="medium-text" width="100" align="right"> &nbsp; <A HREF="<?php echo $MM_moveNext?>">Next 
            20-&gt;</A> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr align="left" bgcolor="#000033"> 
          <td class="medium-text" width="100">Name</td>
          <td class="medium-text" width="200">Colour</td>
          <td class="medium-text" width="180">Breed</td>
          <td class="medium-text" width="160">Owner</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <?php while (($Repeat1__numRows-- != 0) && (!$search->EOF)) 
   { 
?>
        <tr> 
          <td class="medium-text" width="100"> 
            <font size="2"><a class="medium-text" href="show_animal.php?animalID=<?php echo $search->Fields('animalID'); ?>"> 
            <?php echo $search->Fields("animalname")?>
            </a> </font></td>
          <td class="medium-text" width="200"> 
            <font size="2"><i> <a class="medium-text" href="show_animal.php?animalID=<?php echo $search->Fields('animalID'); ?>"> 
            <?php echo $search->Fields("colour")?>
            </a> </i></font></td>
          <td class="medium-text" width="180"> 
            <font size="2"><i> <a class="medium-text" href="show_animal.php?animalID=<?php echo $search->Fields('animalID'); ?>"> 
            <?php echo $search->Fields("breedname")?>
            </a> </i></font></td>
          <td class="medium-text" width="160"> 
            <font size="2"><a class="medium-text" href="show_customer.php?customerID=<?php echo $search->Fields('customerID'); ?>"> 
            <?php echo $search->Fields("firstname")?>
            <?php echo $search->Fields("surname")?>
            </a> </font></td>
        </tr>
        <?php
  $Repeat1__index++;
  $search->MoveNext();
}
?>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
  $search->Close();
?>
