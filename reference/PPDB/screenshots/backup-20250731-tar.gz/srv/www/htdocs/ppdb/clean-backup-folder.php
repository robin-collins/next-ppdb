<?php
  $CurrentDir = getcwd();
  
  $CleanDir = "rm -Rf $CurrentDir/backup/*";
  exec($CleanDir);
  header("Location: index.html");
?>