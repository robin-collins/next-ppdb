<?php 
if (isset($lastvisit))
  {
  $newlast = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $lastvisit);
  $lastvisit = $newlast;
  }
if (isset($thisvisit))
  {
  $newthis = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $thisvisit);
  $thisvisit = $newthis;
  }



function connectDB($query) { 
global $gMainDbHost, $gMainDbName, $gMainDbUser, $gMainDbPass; 
$gMainDbHost = "localhost";
$gMainDbName = "ppdb";
$gMainDbUser = "root";
$gMainDbPass = "6uldv8";

$link = mysql_pconnect($gMainDbHost, $gMainDbUser, $gMainDbPass) or die("Could not connect"); 
$status = mysql_select_db($gMainDbName, $link) or die("Could not select $gMainDbName"); 
$result = mysql_query($query) or print("<li> Query Failed: </li>\n" 
. "<li> errorno = " . mysql_errno() . "</li>\n" 
. "<li> error = " . mysql_error() . "</li>\n" 
. "<li> query = " . $query . "</li>\n"); 
$status = mysql_close($link); 
return($result); 
} 

$query = "SELECT LAST_INSERT_ID()"; 
$result = connectDB($query); 
if ($result) { 
$nrows = mysql_num_rows($result); 
$row = mysql_fetch_row($result); 
$lastID = $row[0]; };
if (isset($animalID)) {$recordID=$animalID;} ELSE {$recordID = $lastID;};
?>
<?php


  //    Copyright (c) Interakt Online 2001
  //    http://www.interakt.ro/

  require("./adodb/adodb.inc.php");
  require("./Connections/ppdb.php");
?>
<?php
  // *** Edit Operations: declare Tables
  $MM_editAction = $PHP_SELF;
  if ($QUERY_STRING) {
    $MM_editAction = $MM_editAction . "?" . $QUERY_STRING;
  }

  $MM_abortEdit = 0;
  $MM_editQuery = "";
?>
<?php
// *** Insert Record: set Variables

if (isset($MM_insert)){

   // $MM_editConnection = MM_ppdb_STRING;
   $MM_editTable  = "notes";
   $MM_editRedirectUrl = "show_animal.php?animalID=$animal->Fields(animalID)";
   $MM_fieldsStr = "animalID|value|date|value|notes|value";
   $MM_columnsStr = "animalID|none,none,NULL|date|',none,NULL|notes|',none,''";

  // create the $MM_fields and $MM_columns arrays
   $MM_fields = explode("|", $MM_fieldsStr);
   $MM_columns = explode("|", $MM_columnsStr);
  
  // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
 }

  // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
  }
}
?>
<?php
  // *** Delete Record: declare variables
  if (isset($MM_delete) && (isset($MM_recordId))) {
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "notes";
    $MM_editColumn = "noteID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "show_animal.php?animalID=$animal->Fields(animalID)";
  
    if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
      $MM_editRedirectUrl = $MM_editRedirectUrl . ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
?>
<?php
  // *** Update Record: set variables
  
  if (isset($MM_update) && (isset($MM_recordId))) {
  
//    $MM_editConnection = $MM_ppdb_STRING;
    $MM_editTable  = "animal";
    $MM_editColumn = "animalID";
    $MM_recordId = "" . $MM_recordId . "";
    $MM_editRedirectUrl = "show_animal.php";
    $MM_fieldsStr = "animalname|value|breedID|value|customerID|value|SEX|value|colour|value|cost|value|lastvisit|value|thisvisit|value|comments|value";
    $MM_columnsStr = "animalname|',none,''|breedID|none,none,NULL|customerID|none,none,NULL|SEX|',none,''|colour|',none,''|cost|none,none,NULL|lastvisit|',none,NULL|thisvisit|',none,NULL|comments|',none,''";
  
    // create the $MM_fields and $MM_columns arrays
   $MM_fields = Explode("|", $MM_fieldsStr);
   $MM_columns = Explode("|", $MM_columnsStr);
    
    // set the form values
  for ($i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $MM_fields[$i+1] = $$MM_fields[$i];
    }
  
    // append the query string to the redirect URL
  if ($MM_editRedirectUrl && $QUERY_STRING && (strlen($QUERY_STRING) > 0)) {
    $MM_editRedirectUrl .= ((strpos($MM_editRedirectUrl, '?') == false)?"?":"&") . $QUERY_STRING;
    }
  }
  ?>
<?php
// *** Insert Record: construct a sql insert statement and execute it
if (isset($MM_insert)) {
   // create the sql insert statement
  $MM_tableValues = "";
  $MM_dbValues = "";
  for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) {
    $formVal = $MM_fields[$i+1];
    $MM_typesArray = explode(",", $MM_columns[$i+1]);
    $delim = $MM_typesArray[0];
    if($delim=="none") $delim="";
    $altVal = $MM_typesArray[1];
    if($altVal=="none") $altVal="";
    $emptyVal = $MM_typesArray[2];
    if($emptyVal=="none") $emptyVal="";
    if ($formVal == "" || !isset($formVal)) {
      $formVal = $emptyVal;
    }
    else {
      if ($altVal != "") {
        $formVal = $altVal;
      }
      else if ($delim == "'") { // escape quotes
        $formVal = $delim . $formVal . $delim;
        //$formVal = "'" . str_replace("'","\'",$formVal) . "'";
      }
      else {
        $formVal = $delim . $formVal . $delim;
      }
    }
    if ($i == 0) {
      $MM_tableValues = $MM_tableValues . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . $formVal;
    }
    else {
      $MM_tableValues = $MM_tableValues . "," . $MM_columns[$i];
      $MM_dbValues = $MM_dbValues . "," . $formVal;
    }
  }
  $MM_editQuery = "insert into " . $MM_editTable . " (" . $MM_tableValues . ") values (" . $MM_dbValues . ")";
  if ($MM_abortEdit!=1) {
    // execute the insert
    $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
    if ($MM_editRedirectUrl) {
      header ("Location: $MM_editRedirectUrl");		
    }
  }
}
?>
<?php
  // *** Delete Record: construct a sql delete statement and execute it
  if (isset($MM_delete) && (isset($MM_recordId))) {
    $MM_editQuery = "delete from " . $MM_editTable . " where " . $MM_editColumn . " = " . $MM_recordId;
    if ($MM_abortEdit!=1) {
      $queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
      if ($MM_editRedirectUrl) {
        header ("Location: $MM_editRedirectUrl");
      }		 
    }
  }
?>
<?php
  // *** Update Record: construct a sql update statement and execute it
  
 if (isset($MM_update) && (isset($MM_recordId))) {
  
	// create the sql update statement
	$MM_editQuery = "update " . $MM_editTable . " set ";
	for ( $i=0; $i+1 < sizeof($MM_fields); ($i=$i+2)) 
	{
		$formVal = $MM_fields[$i+1];
		$MM_typesArray = Explode(",", $MM_columns[$i+1]);
		$delim =    ($MM_typesArray[0] != "none") ? $MM_typesArray[0] : "";
		$altVal =   ($MM_typesArray[1] != "none") ? $MM_typesArray[1] : "";
		$emptyVal = ($MM_typesArray[2] != "none") ? $MM_typesArray[2] : "";
		if ($formVal == "" || !isset($formVal)) 
		{
			$formVal = $emptyVal;
		} 
		else 
		{
			if ($altVal != "") 
			{
				$formVal = $altVal;
			} 
			else if ($delim == "'") 
			{ // do not escape quotes in PHP4
				$formVal = "'" .$formVal . "'";
			} 
			else 
			{
				$formVal = $delim . $formVal . $delim;
			}
		}
		if ($i != 0)
			{
				$MM_editQuery = $MM_editQuery . ", " . $MM_columns[$i] . " = " . $formVal;
			}
			else
			{
				$MM_editQuery = $MM_editQuery . $MM_columns[$i] . " = " . $formVal;
			}
		}

	$MM_editQuery = $MM_editQuery . " where " . $MM_editColumn . " = " . $MM_recordId;

	if ($MM_abortEdit != 1)
	{
		// execute the insert
		$queryrs = $ppdb->Execute($MM_editQuery) or DIE($ppdb->ErrorMsg());
		if ($MM_editRedirectUrl) 
		{
			header ("Location: $MM_editRedirectUrl");
		}		 
	}
}
?>
<?php
$notes__MMColParam = "-1";
if (isset($recordID))
  {$notes__MMColParam = $recordID;}
?>
<?php
$animal__MMColParam = "-1";
if (isset($recordID))
  {$animal__MMColParam = $recordID;}
?>
<?php
$Customer__MMColParam = "-1";
if (isset($recordID))
  {$Customer__MMColParam = $recordID;}
?>
<?php
   $Customer=$ppdb->Execute("SELECT customer.*  FROM customer,animal  WHERE ((customer.customerID = animal.customerID)&&(animal.animalID = " . ($Customer__MMColParam) . "))") or DIE($ppdb->ErrorMsg());
   $Customer_numRows=0;
   $Customer__totalRows=$Customer->RecordCount();
?>
<?php
   $all_breeds=$ppdb->Execute("SELECT * FROM breed ORDER BY breedname ASC") or DIE($ppdb->ErrorMsg());
   $all_breeds_numRows=0;
   $all_breeds__totalRows=$all_breeds->RecordCount();
?>
<?php
   $animal=$ppdb->Execute("SELECT * FROM animal WHERE animalID = " . ($animal__MMColParam) . "") or DIE($ppdb->ErrorMsg());
   $animal_numRows=0;
   $animal__totalRows=$animal->RecordCount();
?>
<?php
   $notes=$ppdb->Execute("SELECT * FROM notes WHERE animalID = " . ($notes__MMColParam) . " ORDER BY date DESC") or DIE($ppdb->ErrorMsg());
   $notes_numRows=0;
   $notes__totalRows=$notes->RecordCount();
?>
<?php
   $Repeat1__numRows = 6;
   $Repeat1__index= 0;
   $notes_numRows = $notes_numRows + $Repeat1__numRows;
?>
<?php
   $Repeat2__numRows = -1;
   $Repeat2__index= 0;
   $all_breeds_numRows = $all_breeds_numRows + $Repeat2__numRows;
?>



<html>
<head>
<script LANGUAGE="JavaScript" SRC="dateslib.js"></script>
<script LANGUAGE="JavaScript" SRC="calendar.js"></script>
<SCRIPT LANGUAGE=javascript>
<!--
function lastvisit_onclick() {
	DateDialogClick(document.form2.lastvisit);
}
function thisvisit_onclick() {
	DateDialogClick(document.form2.thisvisit);
}

// -->
</SCRIPT>
<script language="JavaScript">
<!--
//fully netscape compliant
x = "<?php $this2 = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $animal->Fields('thisvisit')); echo $this2;?>";
y = "<?php echo date("j-m-Y"); ?>"; 
function setValues(first, second) {
	document.form2.lastvisit.value = first;
	document.form2.thisvisit.value = second;
}

function setCost() {
var X = new Array();
<?php while (($Repeat2__numRows-- != 0) && (!$all_breeds->EOF)) 
   { 
?>

X[<?php echo $all_breeds->Fields('breedID'); ?>] = "<?php echo $all_breeds->Fields('avgcost'); ?>";
<?php
  $Repeat2__index++;
  $all_breeds->MoveNext();
}
?>
	document.form2.cost.value = X[document.form2.breedID.options[document.form2.breedID.selectedIndex].value];
}

// -->
</script>
<title> 
<?php echo $animal->Fields("animalname")?>
- 
<?php echo $Customer->Fields("firstname")?>
<?php echo $Customer->Fields("surname")?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>
<?php
$a_l = $animal->Fields("lastvisit");
$a_t = $animal->Fields("thisvisit");

if (isset($a_l))
  {
  $showlast = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $a_l);
  }
if (isset($a_t))
  {
  $showthis = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $a_t);
  }
?>
<body>
<table width="640" border="1" cellspacing="0" cellpadding="0" bordercolor="#000033">
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2" bgcolor="#000033">
        <tr valign="top"> 
          <td width="25" class="large-text" align="center" valign="middle"> 
            <?php 
			  if ($Customer->Fields('email')!="") {?>
            <a class="medium-text" href="mailto:<?php echo $Customer->Fields("email");?>" target="_blank"> 
            <img src="Flash/email.gif" width="20" height="20" alt="Send Customer EMAIL!" name="email"></a> 
            <?php } else { echo("&nbsp;");}; ?>
          </td>
          <td width="25" class="large-text" align="center" valign="middle"><a class="medium-text" href="show_customer.php?customerID=<?php echo $Customer->Fields("customerID")?>"><img src="Flash/questionmark.gif" width="20" height="20" alt="Edit the Customer details." border="0"></a></td>
          <td width="34%" class="large-text" align="left" valign="middle"><a class="large-text" href="show_customer.php?customerID=<?php echo $Customer->Fields("customerID")?>"> 
            <?php echo $Customer->Fields("firstname")?>
            </a><a class="large-text" href="show_customer.php?customerID=<?php echo $Customer->Fields("customerID")?>"> 
            <?php echo $Customer->Fields("surname")?>
            </a><a class="large-text" href="show_customer?customerID=<?php echo $Customer->Fields("customerID")?>"> 
            </a></td>
          <td width="33%" class="small-text" align="right"> 
            <?php echo $Customer->Fields("address")?>
            <?php echo $Customer->Fields("suburb")?>
          </td>
          <td width="33%" class="large-text" align="right" valign="middle"> 
            <?php echo $Customer->Fields("phone1")?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td width="50%" valign="top"> 
            <form method="post" action="<?php echo $MM_editAction?>" name="form2">
              <table border=0 cellpadding=2 cellspacing=0 align="center" width="100%">
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Animal Name:</td>
                  <td class="medium-text" align="left"> 
                    <input type="text" name="animalname" value="<?php echo $animal->Fields("animalname")?>" size="18" tabindex="1" class="input_field">
                    <input type="hidden" name="customerID" value="<?php echo $animal->Fields("customerID")?>" size="32">
                    <input type="hidden" name="MM_recordId" value="<?php echo $animal->Fields("animalID") ?>">
                    <input type="hidden" name="MM_update" value="true">
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Breed:</td>
                  <td class="medium-text" align="left"> 
                    <select name="breedID" onChange="setCost();return false;" tabindex="2" class="input_field">
                      <?php
  if ($all_breeds__totalRows > 0){
    $all_breeds__index=0;
    $all_breeds->MoveFirst();
    WHILE ($all_breeds__index < $all_breeds__totalRows){
?>
                      <OPTION VALUE="<?php echo  $all_breeds->Fields("breedID")?>"<?php if ($all_breeds->Fields("breedID")==$animal->Fields("breedID")) echo "SELECTED";?>> 
                      <?php echo  $all_breeds->Fields("breedname");?>
                      </OPTION>
                      <?php
      $all_breeds->MoveNext();
      $all_breeds__index++;
    }
    $all_breeds__index=0;  
    $all_breeds->MoveFirst();
  }
?>
                    </select>
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Sex:</td>
                  <td class="medium-text" align="left"> 
                    <select name="SEX" tabindex="3" class="input_field">
                      <option value="Male"  <?php echo (($animal->Fields("SEX") == "Male")?"SELECTED":"")?>>Male</option>
                      <option value="Female"  <?php echo (($animal->Fields("SEX") == "Female")?"SELECTED":"")?>>Female</option>
                    </select>
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Colour:</td>
                  <td class="medium-text" align="left"> 
                    <input type="text" name="colour" value="<?php echo $animal->Fields("colour")?>" size="18" tabindex="4" class="input_field">
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Cost:</td>
                  <td class="medium-text" align="left"> 
                    <input type="text" name="cost" value="<?php echo $animal->Fields("cost")?>" size="5" tabindex="5" class="input_field">
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Lastvisit:</td>
                  <td class="medium-text" align="left"> 
                    <input type="text" name="lastvisit" value="<?php echo $showlast;?>" size="13" tabindex="6" class="input_field">
                    <input class="calendar" type="button" name="lastvisit1" value="..." language=javascript onClick="return lastvisit_onclick()">
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Thisvisit:</td>
                  <td class="medium-text" align="left"> 
                    <input type="text" name="thisvisit" value="<?php echo $showthis;?>" size="13" tabindex="7" class="input_field">
                    <input class="calendar" type="button" name="thisvisit1" value="..." language=javascript onClick="return thisvisit_onclick()">
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text">Comments:</td>
                  <td class="medium-text" align="left"> 
                    <textarea name="comments" cols="25" wrap="VIRTUAL" tabindex="8" class="input_fieldMultiline"><?php echo $animal->Fields("comments")?></textarea>
                  </td>
                </tr>
                <tr valign="top"> 
                  <td nowrap align="right" class="medium-text"> 
                    <input type="submit" value="Update Record" name="Submit" tabindex="9" class="button">
                  </td>
                  <td class="medium-text" align="left"> 
                    <input class="button" type="submit" name="change_dates" value="Change Dates" onClick="setValues(x,y);return false;" tabindex="99">
                  </td>
                </tr>
              </table>
            </form>
          </td>
          <td bgcolor="#FFFF99" valign="top"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr> 
                <td align="center" valign="top"> 
                  <form method="POST" action="<?php echo $MM_editAction?>" name="form1">
                    <table border=0 cellpadding=2 cellspacing=0 align="center" width="100%">
                      <tr valign="top"> 
                        <td nowrap align="center" class="date-text"> 
                          <input type="hidden" name="animalID" value="<?php echo $animal->Fields("animalID")?>" size="32">
                          <input type="hidden" name="MM_insert" value="true">
                          <input type="hidden" name="date" value="<?php echo date('Y-m-j')?>" size="32">
                          <textarea name="notes" cols="25" rows="3" tabindex="10" class="note_field"></textarea>
                        </td>
                      </tr>
                      <tr align="center" valign="top"> 
                        <td nowrap> 
                          <input type="submit" name="Submit2" value="Insert NOTE" tabindex="11" class="note_button">
                        </td>
                      </tr>
                    </table>
                  </form>
                  <table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
                    <?php while (($Repeat1__numRows-- != 0) && (!$notes->EOF)) 
   { 
?>
                    <tr valign="top"> 
                      <td width="30" class="date-text" align="right"> 
                        <form name="form3" method="POST" action="<?php echo $MM_editAction?>">
                          <input type="hidden" name="noteID" value="<?php echo $notes->Fields("noteID")?>">
                          <input type="image" border="0" name="imageField" src="Flash/delete-x.gif" alt="Delete Note" width="20" height="20">
                          <input type="hidden" name="MM_delete" value="true">
                          <input type="hidden" name="MM_recordId" value="<?php echo $notes->Fields("noteID") ?>">
                        </form>
                      </td>
                      <td width="100" class="date-text" align="right"> 
                        <i><b> 
                        <?php $newdate = ereg_replace('([0-9]*)[/.-]([0-9]*)[/.-]([0-9]*)','\3-\2-\1', $notes->Fields('date')); echo $newdate;?>
                        </b></i></td>
                      <td class="date-text"> 
                        <?php echo $notes->Fields("notes")?>
                      </td>
                    </tr>
                    <?php
  $Repeat1__index++;
  $notes->MoveNext();
}
?>
                  </table>
                </td>
              </tr>
            </table>
            <p><a href="show-all-notes.php?animalID=<?php echo $animal->Fields("animalID")?>"><strong>All 
              Animal Notes</strong></a></p></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>
</table>
<br>
<br>
<br>
</body>
</html>
<?php
  $Customer->Close();
?>
<?php
  $all_breeds->Close();
?>
<?php
  $animal->Close();
?>
<?php
  $notes->Close();
?>



























  
  
  
  
  
