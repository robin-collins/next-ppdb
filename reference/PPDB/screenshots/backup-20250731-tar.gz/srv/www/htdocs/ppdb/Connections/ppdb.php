<?php 
/* FileName="Connection_php_direct.htm" "driver=sun.jdbc.odbc.JdbcOdbcDriver|url=jdbc:odbc:PPDB|uid=tech|pword=6uldv8" 
 Type="JDBC" 
 Catalog="" 
 Schema=""
 HTTP="false" 
*/
	if(!isset($PHP_SELF)){ 
		$PHP_SELF=getenv("SCRIPT_NAME"); 
	} 
   $MM_ppdb_HOSTNAME = "localhost";
   $MM_ppdb_DBTYPE = "mysql";
   $MM_ppdb_DATABASE = "ppdb";
   $MM_ppdb_USERNAME = "root";
   $MM_ppdb_PASSWORD = "6uldv8";
   ADOLoadCode($MM_ppdb_DBTYPE);
   $ppdb=&ADONewConnection($MM_ppdb_DBTYPE);
   if($MM_ppdb_DBTYPE == "access" || $MM_ppdb_DBTYPE == "odbc"){
   		$ppdb->PConnect($MM_ppdb_DATABASE, $MM_ppdb_USERNAME,$MM_ppdb_PASSWORD);
   } else if($MM_ppdb_DBTYPE == "ibase") {
   		$ppdb->PConnect($MM_ppdb_HOSTNAME.":".$MM_ppdb_DATABASE,$MM_ppdb_USERNAME,$MM_ppdb_PASSWORD);
   } else {
   		$ppdb->PConnect($MM_ppdb_HOSTNAME,$MM_ppdb_USERNAME,$MM_ppdb_PASSWORD,$MM_ppdb_DATABASE);
   }
?>
