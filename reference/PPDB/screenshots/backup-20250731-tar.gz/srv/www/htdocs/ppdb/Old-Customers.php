<?php require_once('Connections/ThePPDB.php'); ?>
<?php
mysql_select_db($database_ThePPDB, $ThePPDB);
$query_OldCustomers = "SELECT customer.surname, customer.firstname, customer.address, customer.suburb, customer.postcode, customer.phone1, customer.phone2, customer.phone3, customer.email, animal.animalname, breed.breedname, animal.thisvisit FROM (customer LEFT JOIN animal ON customer.customerID = animal.customerID) LEFT JOIN breed ON animal.breedID = breed.breedID WHERE ((TO_DAYS(NOW()) - TO_DAYS(thisvisit) >= 180)&&(customer.address<>'')) ORDER BY `surname`, `thisvisit`";
$OldCustomers = mysql_query($query_OldCustomers, $ThePPDB) or die(mysql_error());
$row_OldCustomers = mysql_fetch_assoc($OldCustomers);
$totalRows_OldCustomers = mysql_num_rows($OldCustomers);
?>
<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Customers who have not been in 180 days</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
  <tr bgcolor="#FFFFFF"> 
    <td width="25%">Name</td>
    <td width="25%">Address</td>
    <td width="15%">Phone</td>
    <td width="20%">Animal</td>
    <td width="15%">Last Visit</td>
  </tr>
  <?php do { ?>
  <tr bgcolor="#FFFFFF"> 
    <td width="25%"><?php echo $row_OldCustomers['firstname']; ?>
<?php echo $row_OldCustomers['surname']; ?></td>
    <td width="25%"><?php echo $row_OldCustomers['address']; ?>, <?php echo $row_OldCustomers['suburb']; ?>
<?php echo $row_OldCustomers['postcode']; ?></td>
    <td width="15%"><?php echo $row_OldCustomers['phone1']; ?><br /> <?php echo $row_OldCustomers['phone2']; ?><br /> <?php echo $row_OldCustomers['phone3']; ?> </td>
    <td width="20%"><?php echo $row_OldCustomers['animalname']; ?> - <?php echo $row_OldCustomers['breedname']; ?></td>
    <td width="15%"><?php echo $row_OldCustomers['thisvisit']; ?></td>
  </tr>
  <?php } while ($row_OldCustomers = mysql_fetch_assoc($OldCustomers)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($OldCustomers);
?>

