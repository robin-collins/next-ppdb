<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="tpp.css" type="text/css">
</head>

<body>
<table width="640" border="1" cellspacing="0" cellpadding="2" bordercolor="#000033">
  <tr>
    <td align="center" valign="middle" height="345">THE PAMPERED POOCH<br>
      CUSTOMER RECORD DB
    </td>
  </tr>
  <tr>
    <td align="right"><span class="smallass">DSLIP &copy; 2001</span></td>
  </tr>
</table>

</body>
</html>
