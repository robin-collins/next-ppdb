
function dateslib_DaysTo(theOtherDate){		// equivalent of DateDiff from VB
	var intNoDays;
	intNoDays = parseInt((theOtherDate.valueOf() - this.valueOf()) / (1000 * 3600 * 24));
	return intNoDays;
}
Date.prototype.DaysTo = dateslib_DaysTo;


function dateslib_DaysAdd(NDays){		// equivalent of DateAdd from VB
	var ThisDateAsMs, NDaysAsMs;
	
	// convert everything to milliseconds to work around java data crap
	ThisDateAsMs = this.valueOf();
	NDaysAsMs = NDays * 24 * 3600 * 1000;
	
	// now perform the arithmetic and convert back to date
	ThisDateAsMs += NDaysAsMs;
	this.setTime(ThisDateAsMs);
}
Date.prototype.DaysAdd = dateslib_DaysAdd;

function dateslib_Format(FormatString,option){	// equivalent to Format in VB
	var mm, dd, yy;
	var Months = new Array("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
	mm = this.getMonth();
    dd = this.getDate();
    yy = this.getYear();
    if (yy < 300) yy += 1900;		// some crappy browsers return 101 for 2001
	if (option == 1) {
		if (dd < 10) {
			dd = "0" + dd;
		}
		mm = mm + 1;
		if (mm < 10) {
			mm = "0" + mm;
		}
		return (dd.toString() + "-" + mm + "-" + yy.toString());
	} else {
		return (dd.toString() + " " + Months[mm] + " " + yy.toString());
	}
}
Date.prototype.Format = dateslib_Format;

function dateslib_isDate(){
	var NMillisec;
	NMillisec = Date.parse(this);
	return ((isNaN(NMillisec)==true)?false:true);
}
String.prototype.isDate = dateslib_isDate;

function dateslib_AsDate() {
	var D = new Date();
	var NMillisec;
	
	NMillisec = Date.parse(this);
	if (isNaN(NMillisec))
	{
		// leave default today's date
	}
	else
	{
		D.setTime(NMillisec);		// transfer the date in our variable
	}
	return D;
}
String.prototype.AsDate = dateslib_AsDate;


function dateslib_isTime(){

	if (this.length==0){ return false; }

	var tempString = new String();
	var nMillisec = Date.parse(this);
	if (isNaN(nMillisec)) 
	{
		// invalid date/time - try add a date in front of it just in case
		tempString = "20 oct 1999 " + this;
		nMillisec = Date.parse(tempString);
		if (isNaN(nMillisec)) 
		{		// we are out of luck
				return false;
		}
		else 
		{
			return true;			// valid time, no date
		}
	}
	else 
	{
		// make sure there is no date component
		if (nMillisec > 24 * 3600 * 1000)
		{
			// it must contain a date - return invalid
			return false;
		}
		return true;
	}
}
String.prototype.isTime = dateslib_isTime;


function dateslib_isDuration24(){
	var nv;
	
	// see if it is in hh:mm format (time format)
	if (!this.isTime()){
		// see if it is an integer > 0
		nv = parseInt(this);
		if (isNaN(nv)){
			return false;	// not a duration
		}
		return true;		// duration in minutes
	}
	return true;			// duration in hh:mm format
}
String.prototype.isDuration24 = dateslib_isDuration24;

function dateslib_FormatDuration24(){
	var result;
	var hh, mm;	

	if (!this.isDuration24()){
		return "00:00";				// not a valid duration
	}
	// see if it's already formatted
	if (this.indexOf(":")>=0){
		// already in hh:mm form
		return this.valueOf();
	}
	// this is in numeric format, convert to hours:minutes
	hh = Math.floor(parseInt(this) / 60);
	mm = parseInt(this) - hh * 60;

	// format the result as hh:mm	
	result = ((hh < 10)?"0":"") + hh.toString() + ":";
	result += ((mm < 10)?"0":"") + mm.toString();
	
	return result;		
}
String.prototype.FormatDuration24 = dateslib_FormatDuration24;

function dateslib_getYearEx(){
	var Y;
	Y = this.getYear();
	if (Y<300) {
		Y += 1900;
	}
	return Y;
}
Date.prototype.getYearEx = dateslib_getYearEx;
