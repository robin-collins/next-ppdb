# Screenshots Directory

This directory contains all screenshots from the Pampered Pooch Database application documentation.

## Screenshot List

- `ppdb-main-frameset.png` - Main application frameset view
- Additional screenshots will be added as each feature is documented
