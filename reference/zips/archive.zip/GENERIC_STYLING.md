# Generic UI Style Guide

**Purpose:** A comprehensive design system and implementation guide for creating modern, accessible, and visually consistent web experiences. This guide is derived from the "Soft Luxury" aesthetic but adapted for general use.

---

## 🎨 Design Vision

### Core Principles

1.  **Warm & Premium Aesthetic**
    *   Soft, welcoming color palette.
    *   Organic, rounded shapes (avoiding harsh angles).
    *   Gentle animations with bouncy/smooth easing.
    *   Generous spacing for a premium feel.

2.  **Professional Clarity**
    *   Clean layouts with clear hierarchy.
    *   Trustworthy accent colors for business actions.
    *   Typography that is elegant and highly readable.

3.  **Consistency Through Tokens**
    *   All design values defined as CSS variables.
    *   Reusable component patterns.
    *   Predictable interaction behaviors.

---

## Design Tokens

### CSS Custom Properties

These tokens should be defined in your root CSS file (e.g., `globals.css`).

```css
:root {
  /* === TYPOGRAPHY === */
  /* Display: Elegant serif for headings */
  --font-display: 'Lora', Georgia, serif;
  /* Body: Clean sans-serif for readability */
  --font-body: 'Rubik', -apple-system, BlinkMacSystemFont, sans-serif;
  /* Accent: Geometric sans for UI elements */
  --font-accent: 'Rubik', -apple-system, sans-serif;

  /* === COLOR PALETTE === */
  
  /* Primary Brand Colors (Warm/Gold base) */
  --primary: #d9944a;
  --primary-hover: #c97d3d;
  --primary-light: #fef4e8;
  --primary-dark: #8b5a2b;

  /* Secondary Brand Colors (Teal/Green base) */
  --secondary: #1b9e7e;
  --secondary-hover: #178a6c;
  --secondary-light: #e6f7f3;
  --secondary-dark: #0f6652;

  /* Accent Colors (Bright Highlights) */
  --accent: #2db894;
  --accent-hover: #24a382;
  --accent-light: #d4f4f8;
  --accent-subtle: #a8e6f0;

  /* Semantic Colors */
  --success: #2db894;
  --warning: #e8b876;
  --error: #d97066;
  --info: #a8e6f0;

  /* Neutrals (Warmer Grays) */
  --white: #ffffff;
  --gray-50: #faf8f6;
  --gray-100: #f2ebe5;
  --gray-200: #e8dfd7;
  --gray-300: #d4c7bb;
  --gray-400: #a89b8f;
  --gray-500: #7d7169;
  --gray-600: #5d544d;
  --gray-700: #3d3935;
  --gray-800: #2a2622;
  --gray-900: #1a1614;

  /* === SPACING SCALE === */
  --space-1: 0.25rem;  /* 4px */
  --space-2: 0.5rem;   /* 8px */
  --space-3: 0.75rem;  /* 12px */
  --space-4: 1rem;     /* 16px */
  --space-5: 1.25rem;  /* 20px */
  --space-6: 1.5rem;   /* 24px */
  --space-8: 2rem;     /* 32px */
  --space-10: 2.5rem;  /* 40px */
  --space-12: 3rem;    /* 48px */
  --space-16: 4rem;    /* 64px */
  --space-20: 5rem;    /* 80px */
  --space-24: 6rem;    /* 96px */

  /* === BORDER RADIUS === */
  --radius-sm: 0.5rem;   /* 8px */
  --radius-md: 0.75rem;  /* 12px */
  --radius-lg: 1rem;     /* 16px */
  --radius-xl: 1.5rem;   /* 24px */
  --radius-2xl: 2rem;    /* 32px */
  --radius-3xl: 2.5rem;  /* 40px */
  --radius-full: 9999px; /* Pill */

  /* === SHADOWS === */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  
  /* Colored Shadows */
  --shadow-primary: 0 10px 30px -5px rgba(217, 148, 74, 0.3);
  --shadow-secondary: 0 10px 30px -5px rgba(27, 158, 126, 0.3);

  /* === ANIMATION === */
  --duration-fast: 150ms;
  --duration-normal: 250ms;
  --duration-slow: 350ms;
  
  --ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1);
  --ease-smooth: cubic-bezier(0.4, 0, 0.2, 1);
  --ease-in-out: cubic-bezier(0.4, 0, 0.6, 1);

  /* === Z-INDEX === */
  --z-base: 0;
  --z-dropdown: 100;
  --z-sticky: 100;
  --z-overlay: 150;
  --z-modal: 300;
  --z-toast: 400;
  --z-tooltip: 500;
}
```

---

## Typography System

### Font Imports

```css
@import url('https://fonts.googleapis.com/css2?family=Lora:wght@500;600;700&family=Rubik:wght@400;500;600;700&display=swap');
```

### Base Styles

```css
/* Headings */
h1, h2, h3, h4, h5, h6 {
  font-family: var(--font-display);
  font-weight: 600;
  letter-spacing: -0.02em;
  color: var(--gray-900);
  line-height: 1.2;
}

/* Body */
body, p, li, td {
  font-family: var(--font-body);
  font-weight: 400;
  color: var(--gray-700);
  line-height: 1.6;
}

/* UI Elements */
button, input, select, label, .badge {
  font-family: var(--font-accent);
  letter-spacing: 0.01em;
}
```

### Utility Classes

*   **Page Title:** `text-4xl` (2.5rem), weight 700, serif.
*   **Section Title:** `text-2xl` (1.5rem), weight 600, serif.
*   **Body Large:** `text-lg` (1.125rem), weight 500.
*   **Small/Label:** `text-sm` (0.875rem), weight 500, uppercase tracking.

---

## Component Library

### 1. Buttons

**Base Style:**
```css
.btn {
  padding: var(--space-3) var(--space-5);
  border-radius: var(--radius-lg);
  font-weight: 600;
  transition: all var(--duration-normal) var(--ease-smooth);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  cursor: pointer;
  border: none;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.btn:active {
  transform: translateY(0);
}
```

**Variants:**
*   **Primary:** Background `--primary`, Text White.
*   **Secondary:** Background `--secondary`, Text White.
*   **Outline:** Transparent background, Border `--primary`, Text `--primary`.
*   **Ghost:** Transparent background, Text `--gray-700`, Hover BG `--gray-100`.

### 2. Cards

**Standard Card:**
```css
.card {
  background: white;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius-xl);
  overflow: hidden;
  box-shadow: var(--shadow-sm);
  transition: all var(--duration-normal) var(--ease-smooth);
}

.card:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-2px);
}
```

**Glassmorphic Card:**
```css
.card-glass {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: var(--shadow-xl);
}
```

### 3. Inputs & Forms

**Input Fields:**
```css
.form-input {
  padding: var(--space-3) var(--space-4);
  border: 2px solid var(--gray-200);
  border-radius: var(--radius-lg);
  font-size: 1rem;
  transition: all var(--duration-fast) var(--ease-smooth);
  width: 100%;
}

.form-input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(217, 148, 74, 0.1);
}

.form-input.error {
  border-color: var(--error);
}
```

### 4. Badges

```css
.badge {
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-full);
  font-size: 0.875rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  display: inline-flex;
  align-items: center;
}

/* Variants */
.badge-success { background: var(--success); color: white; }
.badge-warning { background: var(--warning); color: white; }
.badge-neutral { background: var(--gray-200); color: var(--gray-700); }
```

---

## Animations

### Keyframes

**Fade In Up:**
```css
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
```

**Bounce:**
```css
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}
```

**Pulse:**
```css
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.8; transform: scale(1.05); }
}
```

### Usage
Apply animations using utility classes or directly in CSS:
```css
.animate-fade-up {
  animation: fadeInUp 0.5s var(--ease-out) forwards;
}
```

---

## Responsive Guidelines

| Breakpoint | Width | Usage |
| :--- | :--- | :--- |
| **Mobile** | < 480px | Single column, reduced padding (`--space-4`) |
| **Tablet** | < 768px | Stacked grids, moderate padding (`--space-6`) |
| **Desktop** | > 769px | Multi-column, full padding (`--space-8`) |

**Media Query Example:**
```css
.container {
  padding: var(--space-8);
}

@media (max-width: 768px) {
  .container {
    padding: var(--space-6);
  }
}
```

---

## Accessibility Checklist

1.  **Focus Indicators:** Ensure all interactive elements have visible focus states (use `outline` or `box-shadow`).
2.  **Contrast:** Maintain WCAG AA compliance (4.5:1 ratio) for text.
    *   Text on white: Use `--gray-700` or darker.
    *   Links: `--primary` or darker.
3.  **Semantic HTML:** Use `<button>`, `<nav>`, `<main>`, `<h1>`-`<h6>` appropriately.
4.  **ARIA Labels:** Provide `aria-label` for icon-only buttons.
5.  **Keyboard Nav:** Ensure all flows are navigable via keyboard (Tab, Enter, Space, Esc).
