#!/usr/bin/env -S uv run --script

# -*- coding: utf-8 -*-

# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "google-genai",
#   "python-dotenv",
#   "Pillow",
# ]
# ///

import base64
import mimetypes
import os
import datetime
from google import genai
from google.genai import types


BASE_PROMPT=( "Create a high-quality, visually cohesive ‘animal-avatar’ image representing "
              "the breed `{breed}`. Ensure the design seamlessly aligns with and complements the "
              "aesthetics, color palette, and stylistic elements of the provided brand logo image, "
              "maintaining a consistent visual identity across all brand assets." )

BREEDS=[ "Afghan Hound", "Airedale", "Akita", "American Cocker Spanial", "Aust Shepherd", "Aust Terrier", 
             "Basset Fauve De Bretagne", "Bassett Hound", "Beagle", "Bearded Collie", "Bedlington Terrier", 
             "Belgian Shepherd", "Bernese Mountain Dog", "Bichon Frise", "Border Collie", "Border Terrier", 
             "Borzoi", "Boston Terrier", "Bouvier", "Boxer", "Briard", "Brittany Spanial", "Bull Dog", "Bull Terrier", 
             "CairnTerrier", "Cat", "Cattle Dog", "Cavalier King Charles", "Cavalier Spanial", "Cavoodle", 
             "Chihuahua Long Coat", "Chihuahua Smooth Coat", "Chinese Crested", "Chinese Crested Powder Puff", 
             "Chow Chow", "Cocker Spanial small", "Cocker Spaniel", "Collie X", "Corgi", "Curly Coated Retreiver", 
             "Curly Coated Retreiver small", "Dachshund", "Dalmation", "Deerhound", "Dobermann", "Elkhound", 
             "English Setter", "Finnish Lapphund", "Flat Coated Retreiver", "Fox Hound", "Fox Terrier", 
             "Fox Terrier Wire Hair", "French Bulldog", "German Shepherd", "German Shepherd Long Coat", 
             "German Shorthaired Pointer", "German Spitz", "Golden Retreiver Long Coat", "Golden Retriever", 
             "Gordon Setter", "Great Dane", "Grey Hound", "Griffon", "Groodle", "Guinea Pig", "Havanese", 
             "Hunterway", "Huskie", "Irish Setter", "Irish Terrier", "Italian Spinone", "Jack Russell", 
             "Jack Russell Long Coat", "Japanese Chin", "Japanese Spitz", "Keeshound", "Kelpie", 
             "Kerry Blue Terrier", "King Charles Spaniel", "Koolie", "Labradoodle", "Labradoodle Small", 
             "Labrador", "Lagotto Romagnolo", "Lakeland Terrier", "Lhasa Apso", "Lowchen", "Lurchin", 
             "Malamute", "Maltese", "Maremma", "Mastiff", "Moodle", "Musterlander", "New Foundland", 
             "Nova Scotia Duck-Tolling Retriever", "Old English Sheepdog", "Papillion", "Pekinese", 
             "Petit Basset Griffon Vendeen", "Pinscher", "Pointer", "Pomeranian", "Poodle", "Poodle Standard", 
             "Portuguese Water Dog", "Pug", "Puli", "Pyrenean Mountain Dog", "Rabbit", "Ridgeback", "Rottweiler", 
             "Rough Coated Collie", "Saluki", "Samoyed", "Schipperke", "Schnauzer", "Schnauzer Giant", 
             "Schnauzer Minature", "Schnoodle", "Scotty", "Sealyham Terrier", "Shar Pei", "Shetland Sheepdog", 
             "Shiba Inu", "Shih Tzu", "Silky Terrier", "Skye Terrier", "Smooth Coated Collie", 
             "Soft Coated Wheaton Terrier", "Spoodle", "Springer Spaniel", "St Bernard", "Staffy", "Swedish Valhund", 
             "Tenterfield Terrier", "Terriers Large", "Terriers Small", "Tibetan Spaniel", "Tibetan Terrier", "Vizula", 
             "Weimaraner", "Welsh Springer Spanial", "Westie", "Whippet", "White Swiss Shepherd", "Wolfhound", 
             "Yorkshire Terrier" ]

def save_binary_file(file_name, data):
    f = open(file_name, "wb")
    f.write(data)
    f.close()
    print(f"File saved to to: {file_name}")




def generate(PROMPT, output_path=None):
    client = genai.Client(
        api_key=os.environ.get("GEMINI_API_KEY"),
    )

    model = "gemini-3-pro-image-preview"
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_bytes(
                    mime_type="image/png",
                    data=base64.b64decode("""b64 encoded image"""),
                ),
                types.Part.from_text(text=PROMPT),
            ],
        ),
    ]
    generate_content_config = types.GenerateContentConfig(
        response_modalities=[
            "IMAGE",
            "TEXT",
        ],
        image_config=types.ImageConfig(
            aspect_ratio="1:1",
            image_size="1K",
        ),
    )

    file_index = 0
    for chunk in client.models.generate_content_stream(
        model=model,
        contents=contents,
        config=generate_content_config,
    ):
        if (
            chunk.candidates is None
            or chunk.candidates[0].content is None
            or chunk.candidates[0].content.parts is None
        ):
            continue
        if chunk.candidates[0].content.parts[0].inline_data and chunk.candidates[0].content.parts[0].inline_data.data:
            inline_data = chunk.candidates[0].content.parts[0].inline_data
            data_buffer = inline_data.data
            file_extension = mimetypes.guess_extension(inline_data.mime_type) or ".png"
            
            if output_path:
                save_binary_file(output_path, data_buffer)
            else:
                file_name = f"ENTER_FILE_NAME_{file_index}"
                file_index += 1
                save_binary_file(f"{file_name}{file_extension}", data_buffer)
        else:
            print(chunk.text)

if __name__ == "__main__":
    for b in BREEDS:
        CURRENT_PROMPT = BASE_PROMPT.format(breed=b)
        print(f"Currently working on : {b}")
        print(f"using the following prompt:\n{CURRENT_PROMPT}")
        generate(CURRENT_PROMPT)
