# Daily Totals & Analytics Page Overhaul

## 1. Objective
Upgrade the current "Daily Totals" page to a comprehensive analytics dashboard. This involves adding flexible date selection, expanded time period views (including Yearly), and richer data visualizations including revenue trends and breed-specific breakdown.

## 2. UI Requirements

### Control Panel
1.  **Period Selector:** A toggle/dropdown to switch between views:
    *   `Daily`
    *   `Weekly`
    *   `Monthly`
    *   `Yearly` (New)
2.  **Reference Date Input:** A date picker input.
    *   **Default:** Today's date.
    *   **Function:** Acts as the *End Date* for the analysis range. Changing this shifts the look-back window.

## 3. Logic & Time Ranges
The data displayed is calculated backwards from the **Reference Date** based on the selected **Period**.

| Period Selector | Granularity | Range / Duration | Logic |
| :--- | :--- | :--- | :--- |
| **Daily** | Day | 7 Days | `Reference Date` minus 6 days (7 days total). Data grouped by Day. |
| **Weekly** | Week | 8 Weeks | `Reference Date` minus 7 weeks (8 weeks total). Data grouped by Week. |
| **Monthly** | Month | 6 Months | `Reference Date` minus 5 months (6 months total). Data grouped by Month. |
| **Yearly** | Year | 3 Years | `Reference Date` minus 2 years (3 years total). Data grouped by Year. |

## 4. Data Requirements (Backend/API)

The system requires an API endpoint (e.g., `/api/reports/analytics`) capable of accepting `period` and `endDate` parameters to return:

### For Each Time Unit (Day/Week/Month/Year) within Range:
1.  **Label:** Date, Day Name, Month Name, or Year.
2.  **Animal Count:** Total number of animals where `thisvisit` falls within the unit.
3.  **Revenue:** Sum of `cost` for all animals where `thisvisit` falls within the unit.
4.  **Breed Breakdown:** A composition list of breeds visited in that unit (e.g., `{ "Maltese": 5, "Poodle": 3 }`) to support the stacked bar chart.
5.  **Derived Metrics:**
    *   Average Price per Animal.
    *   Trend indicators (comparing to previous unit).

### Period Summary (Aggregate):
1.  Total Revenue for the entire selected range.
2.  Total Animals for the entire selected range.
3.  Overall Average Price.

## 5. Visualization Requirements

### A. Revenue Trends
*   **Type:** Line Graph.
*   **X-Axis:** Time units (Days, Weeks, Months, Years).
*   **Y-Axis:** Currency ($).
*   **Data:** Visualizes the fluctuation of revenue over the selected period.

### B. Animals Processed & Breed Distribution
*   **Type:** Stacked Bar Graph.
*   **X-Axis:** Time units.
*   **Y-Axis:** Count of Animals.
*   **Styling:**
    *   Total height represents total animals for the unit.
    *   **Breed Highlighting:** Segments of the bar should be colored to represent specific breeds that appear significantly (e.g., if 50% are Maltese, half the bar is the "Maltese" color).
    *   **Legend:** Key to identify breed colors.

### C. Summary Footer
*   A text/card based summary section displaying the aggregate totals for the current view.
