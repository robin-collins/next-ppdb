SIDEBAR
✔️ Dashboard
✔️ Search Results
✔️ Add Customer
✔️ Manage Breeds
✔️ Daily Analytics
✔️ Customer History
✔️ Database Backup


HEADER SEARCH BAR
❌ displayed as "list" doesn't include same info as displayed as "cards" 
	missing fields: post code, phone 2, phone 3, colour
	additional field: cost

CONTENTS

Add New Breed
❌ average cost must be in multiples of $5

Add Customer
❌ only mandatory field is surname

Update Customer
❌ cannot add an invalid customer email or phone number >> error: Invalid request data
❌ adding an invalid post code says updated successfully but removes previous valid value

Add Animal



